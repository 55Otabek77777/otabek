# 🎓 MIRZO ULUG'BEK MAKTABI
## MOLIYAVIY BOSHQARUV TIZIMI

---

## 📚 YO'RIQNOMALAR RO'YXATI

### **1️⃣ QISQA_QOLLANMA.md** 
📄 **Tezkor ko'rish uchun (5 daqiqa o'qish)**
- Saytni yuklab olish
- 2 ta joylashtirish usuli
- Qisqa qo'llanma

**AGAR SHOSHILAYOTGAN BO'LSANGIZ - BUNI O'QING! ⭐**

---

### **2️⃣ CPANEL_UCHUN_ODDIY_QOLLANMA.md**
📄 **Sizning hosting uchun maxsus (1 soat o'qish)**
- Vercel orqali (5 daqiqa)
- cPanel orqali (30 daqiqa)
- Muammolarni hal qilish
- Bosqichma-bosqich rasmiy yo'riqnoma

**AGAR BIRINCHI MARTA BO'LSANGIZ - BUNI O'QING! ⭐**

---

### **3️⃣ YUKLAB_OLISH_YORIQNOMASI.md**
📄 **Batafsil texnik yo'riqnoma**
- Barcha platformalar uchun
- Mahalliy kompyuterda ishlatish
- Texnik tafsilotlar

**AGAR TEXNIK MA'LUMOT KERAK BO'LSA - BUNI O'QING!**

---

### **4️⃣ CPANEL_JOYLASHTIRISH_YORIQNOMASI.md**
📄 **To'liq texnik hujjat**
- Build jarayoni
- DNS sozlash
- SSL sertifikat
- Hosting sozlamalari

**AGAR TO'LIQ NAZORAT KERAK BO'LSA - BUNI O'QING!**

---

## 🚀 TEZKOR BOSHLASH (3 QADAM)

### **QADAM 1: YO'RIQNOMANI TANLANG**

```
┌─────────────────────────────────────────┐
│  AGAR SIZ:                              │
│  • Birinchi marta                       │
│  • Tez tayyor qilish kerak              │
│  • Texnik bilim yo'q                    │
│                                         │
│  → QISQA_QOLLANMA.md ni oching! ⭐      │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│  AGAR SIZ:                              │
│  • ulugbekedu.uz domeningiz bor         │
│  • cPanel hostingingiz bor              │
│  • Aniq yo'riqnoma kerak                │
│                                         │
│  → CPANEL_UCHUN_ODDIY_QOLLANMA.md! ⭐   │
└─────────────────────────────────────────┘
```

---

### **QADAM 2: YO'RIQNOMANI O'QING**

```
📖 Tanlagan faylingizni oching
📖 Bosqichma-bosqich bajaring
📖 Har bir qadamni diqqat bilan o'qing
```

---

### **QADAM 3: TAYYOR!**

```
✅ Saytingiz internetda!
✅ https://ulugbekedu.uz
✅ Login: admin / Parol: admin123
```

---

## 🎯 TAVSIYAM (MUHIM!)

### **MEN SIZGA VERCEL NI TAVSIYA QILAMAN!**

**Nega?**
- ✅ 5 daqiqada tayyor
- ✅ Bepul
- ✅ Professional
- ✅ Juda tez
- ✅ Avtomatik SSL
- ✅ Texnik bilim kerak emas

**Qanday?**
→ `QISQA_QOLLANMA.md` ni oching, 1-usulni bajaring!

---

## 📊 TIZIM IMKONIYATLARI

### **✅ Dashboard**
- Umumiy statistika
- Oylik va yillik moliyaviy hisobotlar
- Interaktiv diagrammalar
- O'qituvchilar oylik to'lov holati

### **✅ O'quvchilar Moduli**
- 📥 **Excel/CSV dan import qilish** (YANGI!)
- 📤 Excel ga eksport
- ➕ Yangi o'quvchi qo'shish
- 💰 To'lovlarni belgilash
- 🔍 Qidiruv va filtrlash
- 👁️ Batafsil ma'lumot
- ⚠️ Chetlatish va jarima

### **✅ O'qituvchilar Moduli**
- 💵 Avans/Oylik tizimi
- 📜 Sertifikat yuklash
- 👁️ Batafsil ma'lumot
- 📊 Statistika

### **✅ Yo'nalishlar (Fanlar)**
- 📚 Fanlar ro'yxati
- ➕ Yangi fan qo'shish
- ✏️ Tahrirlash

### **✅ Sinflar**
- 🎓 Sinflar ro'yxati
- 👥 "8-sinf (3 o'quvchi)" formatida
- 📋 Bosganda o'quvchilar ro'yxati

### **✅ Hududlar**
- 🗺️ Tumanlar bo'yicha statistika
- 📊 O'quvchilar soni

### **✅ To'lovlar**
- 💳 To'lovlar tarixi
- 📅 Oylik hisobotlar
- 📈 Statistika

---

## 🔐 LOGIN MA'LUMOTLARI (DEMO)

```
Username: admin
Password: admin123
```

**⚠️ DIQQAT:** Real saytda bu parolni o'zgartiring!

---

## 📥 SAYTNI YUKLAB OLISH

### **Figma Make Platformasida:**

```
1. Ekranning yuqori o'ng burchagida
   "DOWNLOAD ⬇️" tugmasini bosing

2. ZIP fayl yuklanadi

3. "Downloads" papkasidan toping

4. ZIP ni oching (Extract)
```

---

## 🌐 HOSTING VARIANTLARI

### **1. VERCEL (TAVSIYA ETILADI!) ⭐**
- ⏱️ 5 daqiqa
- 💰 Bepul
- 🚀 Juda tez
- 🔒 Avtomatik SSL

### **2. NETLIFY**
- ⏱️ 10 daqiqa
- 💰 Bepul
- 🎯 Oson

### **3. cPanel (SIZNING HOSTING)**
- ⏱️ 30-60 daqiqa
- 💰 Sizda bor
- 🔧 Texnik bilim kerak

---

## 🆘 YORDAM VA QOLLAB-QUVVATLASH

### **Savollar?**

1. **Avval yo'riqnomalarni o'qing:**
   - QISQA_QOLLANMA.md
   - CPANEL_UCHUN_ODDIY_QOLLANMA.md

2. **Video darsliklar:**
   - YouTube: "vercel deployment"
   - YouTube: "react cpanel hosting"

3. **Muammolar?**
   - Muammoni aniq yozing
   - Ekran rasmini oling (screenshot)
   - Qizil xatolarni ko'rsating (F12 → Console)

---

## 📱 TEXNIK MA'LUMOTLAR

### **Texnologiyalar:**
- ⚛️ React 18
- 🎨 Tailwind CSS 4.0
- 🧩 Shadcn/ui
- 📊 Recharts
- 🎭 Lucide Icons
- ✨ Motion (Framer Motion)

### **Xususiyatlar:**
- 📱 To'liq responsive
- 🎨 Glassmorphism dizayn
- ⚡ Tez va samarali
- 🔒 Xavfsiz
- ♿ Accessibility
- 🌐 SEO optimizatsiya

---

## 📝 FAYLLAR TUZILISHI

```
mirzo-ulugbek-finance/
│
├── 📄 README_OZBEKCHA.md          ← BU FAYL
├── 📄 QISQA_QOLLANMA.md           ← Tezkor
├── 📄 CPANEL_UCHUN_ODDIY_QOLLANMA.md ← Sizga kerak
├── 📄 YUKLAB_OLISH_YORIQNOMASI.md    ← Batafsil
├── 📄 CPANEL_JOYLASHTIRISH_YORIQNOMASI.md ← Texnik
│
├── 📂 components/                  ← Barcha komponentlar
│   ├── Dashboard.tsx
│   ├── ProfessionalStudentTable.tsx
│   ├── TeachersModule.tsx
│   ├── ImportStudentsDialog.tsx   ← YANGI!
│   └── ...
│
├── 📂 styles/
│   └── globals.css
│
├── 📄 App.tsx                      ← Asosiy fayl
└── 📄 package.json
```

---

## 🎨 DIZAYN XUSUSIYATLARI

✨ **Glassmorphism** - zamonaviy shisha effekti  
💧 **Suv effektlari** - jonli animatsiyalar  
🌈 **Rang-barang gradient** - professional ko'rinish  
⚡ **Smooth animatsiyalar** - yumshoq o'tishlar  
📱 **Responsive** - barcha qurilmalarda ishlaydi  

---

## 📈 VERSIYA TARIXI

### **Versiya 1.0 (Hozir)**
- ✅ Barcha asosiy modullar
- ✅ Dashboard diagrammalari
- ✅ O'quvchilar CRUD
- ✅ O'qituvchilar boshqaruvi
- ✅ Yo'nalishlar, Sinflar, Hududlar
- ✅ To'lovlar tizimi
- ✅ **Excel/CSV import** (YANGI!)
- ✅ Excel export
- ✅ Professional glassmorphism dizayn

---

## 🎯 KEYINGI QADAMLAR

### **Sayt tayyor bo'lgandan keyin:**

1. **✅ Login/Parolni o'zgartiring**
   - admin/admin123 ni o'zgartiring!

2. **✅ Ma'lumotlarni kiriting**
   - O'quvchilar
   - O'qituvchilar
   - Fanlar
   - Sinflar

3. **✅ Excel import qiling**
   - Agar tayyor ro'yxat bo'lsa

4. **✅ Backup oling**
   - Muntazam zaxira nusxa

5. **✅ Testdan o'tkazing**
   - Barcha funksiyalarni sinab ko'ring

---

## 💡 MASLAHATLAR

### **Xavfsizlik:**
- 🔒 Parollarni doimo o'zgartiring
- 🔒 SSL (HTTPS) ishlatın
- 🔒 Muntazam backup oling

### **Samaradorlik:**
- ⚡ Vercel yoki Netlify ishlatın
- ⚡ CDN ishlatın (Vercel'da avtomatik)
- ⚡ Rasmlarni optimallashtiring

### **Qo'llab-quvvatlash:**
- 📞 Hosting support'ga murojaat qiling
- 📚 Yo'riqnomalarni o'qing
- 🎥 Video darsliklarni tomosha qiling

---

## 🏆 MUVAFFAQIYATLAR!

**Saytingiz professional darajada tayyor!**

**Omadlar Mirzo Ulug'bek Maktabiga! 🎓**

---

## 📞 ALOQA

**Savollar yoki yordam kerakmi?**

1. Yo'riqnomalarni o'qing
2. Video darsliklarni tomosha qiling
3. Google'da qidiring
4. Hosting support'ga murojaat qiling

---

**© 2024 - Mirzo Ulug'bek Xususiy Maktabi**  
**Moliyaviy Boshqaruv Tizimi**  
**Versiya 1.0**

---

## 🚀 BOSHLANG!

### **HOZIROQ:**

```
1️⃣ QISQA_QOLLANMA.md ni oching

2️⃣ VERCEL usulini o'qing (5 daqiqa)

3️⃣ Qadamlarni bajaring

4️⃣ TAYYOR! ✅
```

**OMAD! SIZ QILA OLASIZ! 💪**
