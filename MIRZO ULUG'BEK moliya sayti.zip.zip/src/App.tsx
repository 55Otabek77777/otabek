import { useState } from "react";
import { LoginPage } from "./components/LoginPage";
import { MainLayout } from "./components/MainLayout";
import logoImage from "figma:asset/2f48f3791ecd205478f12f766bf06a64507cd70c.png";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = () => {
    setIsLoading(true);
    // Simulate login process
    setTimeout(() => {
      setIsAuthenticated(true);
      setIsLoading(false);
    }, 2000);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 flex items-center justify-center">
        <div className="text-center">
          <div className="relative">
            <div className="w-32 h-32 mx-auto mb-6 relative">
              {/* Logo animation */}
              <div className="absolute inset-0 bg-white/20 backdrop-blur-xl rounded-full animate-ping"></div>
              <div className="absolute inset-0 bg-white backdrop-blur-xl rounded-full flex items-center justify-center animate-spin-slow">
                <img 
                  src={logoImage} 
                  alt="Mirzo Ulug'bek Logo" 
                  className="w-24 h-24 object-contain"
                />
              </div>
            </div>
            <h2 className="text-white text-2xl mb-2">Mirzo Ulug'bek Xususiy Maktabi</h2>
            <p className="text-white/80 text-lg mb-4">Biroz kuting...</p>
            <div className="flex gap-2 justify-center">
              <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{animationDelay: '0s'}}></div>
              <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
              <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return <MainLayout onLogout={handleLogout} />;
}