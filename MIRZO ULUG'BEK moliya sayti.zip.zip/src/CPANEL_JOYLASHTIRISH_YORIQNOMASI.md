# 🚀 CPANEL ORQALI SAYTNI JOYLASHTIRISH (BOSQICHMA-BOSQICH)

## 📋 SIZNING DOMEN MA'LUMOTLARINGIZ

```
✅ Domen: ulugbekedu.uz
✅ Server IP: 37.153.159.11
✅ Username: ulugbeke
✅ Hosting: Tayyor
```

---

## ⚠️ MUHIM ESLATMA!

**Bu loyiha REACT (JavaScript framework) da yozilgan!**

Bu oddiy HTML/CSS/JS emas, shuning uchun ikki xil usul bor:

### **VARIANT 1: VERCEL/NETLIFY (5 DAQIQA) - ENG OSON ✅**
### **VARIANT 2: BUILD QILIB cPanel'GA (30 DAQIQA) - QIYINROQ**

Men sizga **IKKALA USULNI HAM** ko'rsataman, siz o'zingiz tanlang!

---

# 🟢 VARIANT 1: VERCEL ORQALI (ENG OSON - TAVSIYA ETILADI!)

Bu usulda sayt **2-3 daqiqada** tayyor bo'ladi va avtomatik **ulugbekedu.uz** domeningizga ulanadi!

## QADAMLAR:

### **1️⃣ Vercel'ga ro'yxatdan o'ting**

```
🌐 Sayt: https://vercel.com
```

1. **"Sign Up" tugmasini bosing**
2. **GitHub orqali kirish:**
   - "Continue with GitHub" tugmasini bosing
   - GitHub'da ro'yxatdan o'ting (agar yo'q bo'lsa)
   - Vercel'ga ruxsat bering

*Yoki Email orqali kirish mumkin*

---

### **2️⃣ Loyihani yuklash**

1. **Figma Make'dan saytni yuklab oling:**
   - Ekranning yuqori o'ng burchagida **"Download"** tugmasini bosing
   - ZIP fayl yuklab olinadi

2. **Vercel Dashboard'ga o'ting:**
   - "New Project" tugmasini bosing

3. **Fayllarni yuklash:**
   - **"Import Git Repository"** o'rniga pastda
   - **"Browse Template"** yonida **"Upload"** yoki **"Import"** bo'lishi mumkin
   - Yoki GitHub'ga yuklab, u yerdan import qiling (ko'proq tavsiya etiladi)

---

### **3️⃣ GitHub orqali yuklash (OSON USUL)**

1. **GitHub'ga kiring:** https://github.com

2. **Yangi repository yarating:**
   - "+" belgisi → "New repository"
   - Nom: `mirzo-ulugbek-finance`
   - "Create repository" tugmasini bosing

3. **Fayllarni GitHub'ga yuklash:**
   - Yangi repository sahifasida "uploading an existing file" ni bosing
   - ZIP faylni extract qilib, ichidagi barcha fayllarni sudrab tashlang
   - "Commit changes" tugmasini bosing

4. **Vercel'da import qilish:**
   - Vercel → "New Project"
   - "Import Git Repository"
   - GitHub repository'ni tanlang
   - "Deploy" tugmasini bosing

**2-3 DAQIQADA TAYYOR! ✅**

---

### **4️⃣ O'z domeningizni ulash (ulugbekedu.uz)**

1. **Vercel'da deployed loyihangizni oching**

2. **Settings → Domains ga o'ting**

3. **Domenni qo'shing:**
   ```
   ulugbekedu.uz
   ```

4. **DNS sozlamalarini yangilash:**

   **cPanel'ga kiring va DNS sozlamalarini o'zgartiring:**

   **A. cPanel → "Zone Editor" ga o'ting**

   **B. Quyidagi yozuvlarni qo'shing:**

   ```
   Type: A
   Name: @
   IPv4 Address: 76.76.21.21
   TTL: 3600

   Type: CNAME
   Name: www
   CNAME: cname.vercel-dns.com
   TTL: 3600
   ```

   *Vercel sizga aniq IP va CNAME beradi, yuqoridagilar namuna*

5. **Kutish:**
   - DNS yangilanishi 10 daqiqa - 48 soat olishi mumkin
   - Odatda 10-30 daqiqada ishlaydi

**TAYYOR! Saytingiz https://ulugbekedu.uz da ishlaydi! 🎉**

---

# 🔵 VARIANT 2: cPanel ORQALI (Build qilib)

Bu usul biroz qiyinroq, lekin to'liq nazorat beradi.

## BOSQICH 1: SAYTNI MAHALLIY KOMPYUTERDA BUILD QILISH

### **1️⃣ Node.js o'rnating**

```
🌐 https://nodejs.org/
```

1. "LTS" versiyasini yuklab oling
2. O'rnating (barcha sozlamalar default bo'lsin)
3. Kompyuterni qayta ishga tushiring

---

### **2️⃣ Sayt fayllarini tayyorlash**

1. **Figma Make'dan ZIP faylni yuklab oling**
2. **ZIP ni extract qiling**
3. **Papkani oching**

---

### **3️⃣ Terminal/Command Prompt orqali build qilish**

**Windows'da:**

1. Papkaga o'ting (Shift + O'ng tugma → "Open PowerShell window here")
2. Yoki papka manzilini nusxalab CMD'da:
   ```
   cd C:\Users\YourName\Downloads\mirzo-ulugbek-finance
   ```

**Komandalar:**

```bash
# 1. Dependencies o'rnatish
npm install

# 2. Build qilish
npm run build
```

**3-5 daqiqa kutish...**

**Natija:** `dist` yoki `build` nomli papka paydo bo'ladi - SHU KERAK! ✅

---

## BOSQICH 2: cPanel ORQALI FAYLLARNI YUKLASH

### **1️⃣ cPanel'ga kirish**

```
🌐 https://ulugbekedu.uz:2083
yoki
🌐 https://ulugbekedu.uz/cpanel

Username: ulugbeke
Password: [sizning parolingiz]
```

---

### **2️⃣ File Manager'ni ochish**

1. cPanel'da **"File Manager"** ni toping va oching
2. **"public_html"** papkasiga o'ting

---

### **3️⃣ Eski fayllarni o'chirish (agar bor bo'lsa)**

1. `public_html` ichidagi barcha fayllarni belgilang
2. **"Delete"** tugmasini bosing
3. Tasdiqlang

---

### **4️⃣ Yangi fayllarni yuklash**

1. **"Upload"** tugmasini bosing

2. **Build qilingan fayllarni tanlash:**
   - Kompyuteringizdagi `dist` yoki `build` papkasini oching
   - Ichidagi **BARCHA fayllarni** belgilang
   - Yuklang

   **YOKI ZIP qilib yuklash:**
   - `dist` papkasini ZIP ga o'giring
   - ZIP ni yuklang
   - File Manager'da ZIP faylga o'ng tugma → "Extract"

3. **Yuklash tugaguncha kutish...**

---

### **5️⃣ .htaccess fayl yaratish (React uchun muhim!)**

1. File Manager'da **"New File"** tugmasini bosing
2. Fayl nomi: `.htaccess`
3. Faylni oching va quyidagini qo'ying:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>

# Gzip siqish
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/x-javascript
</IfModule>

# Browser caching
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType image/jpg "access plus 1 year"
  ExpiresByType image/jpeg "access plus 1 year"
  ExpiresByType image/gif "access plus 1 year"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType text/css "access plus 1 month"
  ExpiresByType application/pdf "access plus 1 month"
  ExpiresByType text/x-javascript "access plus 1 month"
  ExpiresByType application/x-shockwave-flash "access plus 1 month"
  ExpiresByType image/x-icon "access plus 1 year"
  ExpiresDefault "access plus 2 days"
</IfModule>
```

4. **"Save Changes"** tugmasini bosing

---

### **6️⃣ Natijani tekshirish**

```
🌐 https://ulugbekedu.uz
```

Brauzerda oching!

**TAYYOR! ✅**

---

## 🔧 MUAMMOLAR VA YECHIMLAR

### **Muammo 1: "404 Not Found" xatosi**

**Yechim:**
- `.htaccess` fayli to'g'ri yaratilganligini tekshiring
- Barcha fayllar `public_html` ichida ekanligini tekshiring

---

### **Muammo 2: Sahifa oq ekran**

**Yechim:**
1. Brauzerda F12 ni bosing → Console'ni oching
2. Qizil xatolarni ko'ring
3. Odatda fayl yo'llari muammosi:
   - `index.html` ni oching (File Manager'da)
   - Agar `/assets/...` kabi yo'llar bo'lsa, to'g'ri

---

### **Muammo 3: CSS/JS yuklanmaydi**

**Yechim:**
1. File Manager'da `assets` papkasi borligini tekshiring
2. MIME types sozlamalarini tekshiring:
   - cPanel → "MIME Types"
   - `.css` → `text/css`
   - `.js` → `application/javascript`

---

## 📊 FAYL TUZILISHI (public_html ichida)

```
public_html/
├── index.html              # Asosiy fayl
├── assets/                 # CSS, JS, rasmlar
│   ├── index-[hash].js
│   ├── index-[hash].css
│   └── ...
├── .htaccess              # Rewrite qoidalar
└── favicon.ico            # Ikonka
```

---

## 🎯 QAYSI USULNI TANLASH?

### **✅ VERCEL (Variant 1) - TAVSIYA ETILADI:**
- ✅ 5 daqiqada tayyor
- ✅ Avtomatik yangilanish
- ✅ Bepul SSL
- ✅ Tez ishlash
- ✅ Texnik bilim kerak emas

### **⚡ cPanel (Variant 2):**
- ⚠️ 30-60 daqiqa vaqt
- ⚠️ Node.js va build kerak
- ⚠️ Texnik bilim kerak
- ✅ To'liq nazorat
- ✅ O'z serveringizda

---

## 📞 YORDAM UCHUN

**Agar muammo bo'lsa:**
1. Screenshot oling (F12 → Console)
2. Qizil xatolarni ko'ring
3. Google'da qidiring: "[xato matni] react cpanel"

**Video darsliklar:**
- YouTube: "How to deploy React app to cPanel"
- YouTube: "React routing on shared hosting"

---

## 🎉 YAKUN

**VARIANT 1 (VERCEL)** - ENG OSON ✅

Agar texnik jihatdan qiyin bo'lsa, Vercel'dan foydalaning. U bepul, tez va professional!

**Domeningizni Vercel'ga ulash juda oson va 10 daqiqada tayyor bo'ladi!**

---

**Muvaffaqiyatlar! 🚀**

**Savollar bo'lsa, so'rang!**
