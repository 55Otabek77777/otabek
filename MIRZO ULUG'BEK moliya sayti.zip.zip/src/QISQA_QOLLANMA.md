# 🚀 MIRZO ULUG'BEK MAKTABI - MOLIYAVIY TIZIM
## TEZKOR YO'RIQNOMA

---

## 📥 1. SAYTNI YUKLAB OLISH

```
┌─────────────────────────────────────────┐
│                                         │
│  Figma Make ekranining yuqori o'ng      │
│  burchagida "DOWNLOAD ⬇️" tugmasini    │
│  BOSING                                 │
│                                         │
│  → ZIP fayl yuklanadi                   │
│  → "Downloads" papkasidan toping        │
│  → ZIP ni oching (Extract)              │
│                                         │
└─────────────────────────────────────────┘
```

---

## 🌐 2. INTERNETGA CHIQARISH (2 USUL)

### ✅ **USUL 1: VERCEL (5 DAQIQA - ENG OSON!)**

**QADAMLAR:**

```
1️⃣  https://vercel.com → "Sign Up"
    (GitHub yoki Email orqali)

2️⃣  "New Project" → "Import Git Repository"

3️⃣  ZIP faylni GitHub'ga yuklash:
    - https://github.com → yangi repo
    - Fayllarni yuklash
    - Vercel'da import qilish

4️⃣  "Deploy" → 2 daqiqada TAYYOR! ✅
```

**DOMENNI ULASH:**

```
Vercel → Settings → Domains

ulugbekedu.uz ni qo'shing

cPanel'da DNS o'zgartirish:
  A Record: @ → 76.76.21.21
  CNAME: www → cname.vercel-dns.com

10-30 daqiqada ishlaydi! ✅
```

---

### ⚡ **USUL 2: cPanel (30 DAQIQA - QIYINROQ)**

**QADAMLAR:**

```
1️⃣  Node.js o'rnatish:
    https://nodejs.org → LTS yuklab olish

2️⃣  ZIP faylni oching
    Papkada terminal/CMD oching:
    
    npm install
    npm run build
    
    → "dist" papka paydo bo'ladi ✅

3️⃣  cPanel'ga kirish:
    https://ulugbekedu.uz:2083
    Username: ulugbeke
    Password: [parolingiz]

4️⃣  File Manager → public_html
    Eski fayllarni o'chirish
    
5️⃣  "dist" papkadagi BARCHA fayllarni
    public_html ga yuklash

6️⃣  .htaccess fayl yaratish:
    (Pastdagi kodni nusxalash)

7️⃣  https://ulugbekedu.uz → TAYYOR! ✅
```

**.htaccess kodi:**

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

---

## 🎯 QAYSI USULNI TANLASH?

| **Xususiyat**        | **VERCEL** | **cPanel** |
|----------------------|------------|------------|
| Vaqt                 | 5 daqiqa   | 30 daqiqa  |
| Qiyinlik             | Juda oson  | O'rtacha   |
| Texnik bilim         | Kerak emas | Kerak      |
| Bepul SSL            | ✅ Ha      | ⚠️ Sozlash |
| Tezlik               | ✅ Tez     | O'rtacha   |
| Yangilanish          | Avtomatik  | Qo'lda     |
| **TAVSIYA**          | **✅✅✅**  | ⚠️         |

---

## 📊 EXCEL IMPORT QANDAY ISHLAYDI?

```
1️⃣  O'quvchilar bo'limi → "Excel dan import"

2️⃣  "Shablon yuklab olish" tugmasi
    → Oquvchilar_Shablon.csv yuklanadi

3️⃣  Shablonni to'ldirish:
    - Excel/Google Sheets da ochish
    - O'quvchilar ma'lumotlarini yozish
    - CSV formatida saqlash (UTF-8)

4️⃣  "Fayl tanlash" → CSV yuklash
    → "Import qilish"

5️⃣  TAYYOR! Barcha o'quvchilar qo'shildi ✅
```

**Shablon formati:**
```
№,ISM,TUG'ILGAN,TUMAN,MANZIL,TEL1,TEL2,SINF,FAN1,FAN2
1,Aliyev Ali,01.01.2010,Toshkent,Chilonzor,...
```

---

## 🔐 LOGIN MA'LUMOTLARI

```
Login: admin
Parol: admin123
```

⚠️ **Eslatma:** Real saytda parolni o'zgartiring!

---

## 🎨 TIZIM IMKONIYATLARI

✅ **Dashboard** - statistika, diagrammalar  
✅ **O'quvchilar** - Excel import/export  
✅ **O'qituvchilar** - avans/oylik  
✅ **Yo'nalishlar** - fanlar ro'yxati  
✅ **Sinflar** - o'quvchilar bo'yicha  
✅ **Hududlar** - tumanlar statistikasi  
✅ **To'lovlar** - to'lov tarixi  

---

## 📞 YORDAM

**Muammolarni hal qilish:**
1. Brauzerda F12 bosing
2. "Console" ga o'ting
3. Qizil xatolarni ko'ring
4. Google'da qidiring

**Video darsliklar:**
- "Vercel deployment tutorial"
- "React app to cPanel"

---

## ✅ XULOSA

### **AGAR TEZKOR KERAK BO'LSA:**
→ **VERCEL ishlatıng!** (5 daqiqa)

### **AGAR TEXNIK TAJRIBANGIZ BOR BO'LSA:**
→ **cPanel ishlatıng!** (30 daqiqa)

---

## 🎉 MUVAFFAQIYATLAR!

**Saytingiz professional darajada tayyor!**

**Domeningiz:** https://ulugbekedu.uz  
**Support:** cPanel hosting provider'ingiz

---

**© 2024 - Mirzo Ulug'bek Xususiy Maktabi**  
**Moliyaviy Boshqaruv Tizimi v1.0**

---

### 📝 TO'LIQ YO'RIQNOMALAR:

1. **YUKLAB_OLISH_YORIQNOMASI.md** - batafsil ma'lumot
2. **CPANEL_JOYLASHTIRISH_YORIQNOMASI.md** - cPanel uchun
3. **QISQA_QOLLANMA.md** - bu fayl (tez yordam)

---

**Savollar? Muammolar?**  
Batafsil yo'riqnomalarni o'qing! ⬆️
