# 📱 cPanel UCHUN ODDIY YO'RIQNOMA
## SIZNING DOMENINGIZ: ulugbekedu.uz

---

## ⚠️ MUHIM! BIRINCHI O'QING!

**Bu React loyihasi!** Oddiy HTML emas!

**2 ta yo'l bor:**

### ✅ **YO'L 1: VERCEL (OSON - 5 DAQIQA)**
### ⚠️ **YO'L 2: cPanel (QIYIN - 1 SOAT)**

**MEN SIZGA VERCEL NI TAVSIYA QILAMAN!**

Lekin ikkala yo'lni ham tushuntiraman.

---

# 🟢 YO'L 1: VERCEL ORQALI (TAVSIYA!)

## NEGA VERCEL?

✅ 5 daqiqada tayyor  
✅ Texnik bilim kerak emas  
✅ Bepul SSL (HTTPS)  
✅ Juda tez ishlaydi  
✅ Avtomatik yangilanish  
✅ Domeningizni osongina ulaysiz  

---

## QADAMLAR (5 DAQIQA):

### **QADAM 1: Vercel'ga kirish**

```
1. Brauzerda oching: https://vercel.com

2. "Sign Up" tugmasini bosing

3. "Continue with GitHub" ni bosing
   (yoki email orqali)

4. Ro'yxatdan o'ting
```

---

### **QADAM 2: GitHub'ga fayl yuklash**

```
1. GitHub.com ga kiring (yangi sahifa)

2. "+" belgisi (yuqori o'ng) → "New repository"

3. Repository nomi: mirzo-maktab

4. "Create repository" tugmasini bosing

5. Sahifada "uploading an existing file" ni bosing

6. Figma Make'dan yuklab olingan ZIP faylni
   extract qiling (oching)

7. BARCHA fayllarni GitHub'ga sudrab tashlang
   (Drag & Drop)

8. "Commit changes" tugmasini bosing
```

---

### **QADAM 3: Vercel'da deploy qilish**

```
1. Vercel.com ga qayting

2. "New Project" tugmasini bosing

3. "Import Git Repository" ni tanlang

4. GitHub repository'ni ko'rasiz → "Import"

5. Hech narsa o'zgartirmasdan "Deploy" bosing

6. 2-3 daqiqada TAYYOR! ✅

   Sizga link beriladi:
   https://mirzo-maktab.vercel.app
```

---

### **QADAM 4: O'z domeningizni ulash (ulugbekedu.uz)**

```
1. Vercel'da loyihangizni oching

2. "Settings" (yuqorida) → "Domains" (chap menyu)

3. "Add" tugmasini bosing

4. Kiriting: ulugbekedu.uz

5. "Add" tugmasini bosing

6. Sizga 2 ta yo'riqnoma ko'rsatiladi:
   - A Record
   - CNAME Record
```

---

### **QADAM 5: cPanel'da DNS sozlash**

```
1. cPanel'ga kiring:
   https://ulugbekedu.uz:2083
   
   Username: ulugbeke
   Password: [parolingiz]

2. "Zone Editor" ni toping va oching

3. "A Record" qo'shish:
   - Name: @ (yoki ulugbekedu.uz)
   - Type: A
   - Address: [Vercel bergan IP, masalan: 76.76.21.21]
   - TTL: 3600
   - "Add Record" bosing

4. "CNAME Record" qo'shish:
   - Name: www
   - Type: CNAME
   - CNAME: cname.vercel-dns.com
   - TTL: 3600
   - "Add Record" bosing

5. "Save" yoki "Update" bosing
```

---

### **QADAM 6: Kutish va tekshirish**

```
⏱️ 10-30 daqiqada tayyor bo'ladi

Tekshirish:
- https://ulugbekedu.uz
- Brauzerda oching

✅ TAYYOR! Saytingiz ishlaydi!
```

---

# 🔵 YO'L 2: cPanel ORQALI (QIYIN)

**⚠️ DIQQAT:** Bu yo'l qiyinroq va ko'proq vaqt talab qiladi!

Agar siz texnik bilimga ega bo'lmasangiz, **YO'L 1 (VERCEL)** ni tanlang!

---

## QADAM 1: Kompyuterda tayyorgarlik

### **1.1: Node.js o'rnatish**

```
1. Saytni oching: https://nodejs.org/

2. "LTS" (chap tugma) ni yuklab oling

3. Yuklab olingan faylni ishga tushiring

4. "Next" → "Next" → "Install"

5. Kompyuterni qayta ishga tushiring

6. Tekshirish:
   - Windows: Win+R → cmd → Enter
   - Yozing: node -v
   - Versiya chiqsa ✅ tayyor
```

---

### **1.2: Sayt fayllarini tayyorlash**

```
1. Figma Make'dan saytni yuklab oling (ZIP)

2. ZIP faylni oching (Extract)
   - Windows: o'ng tugma → "Extract All"
   - Papka ochiladi

3. Papka manzilini eslang, masalan:
   C:\Users\Admin\Downloads\mirzo-maktab
```

---

### **1.3: BUILD qilish (MUHIM!)**

```
1. Papkani oching (yuqoridagi)

2. Papka ichida:
   - Shift + O'ng tugma
   - "Open PowerShell window here"
   
   (Agar yo'q bo'lsa, CMD da):
   - Win+R → cmd → Enter
   - cd C:\Users\Admin\Downloads\mirzo-maktab

3. Quyidagi komandalarni kiriting:

   npm install
   
   (5-10 daqiqa kutish...)
   
   npm run build
   
   (2-3 daqiqa kutish...)

4. Papkada "dist" yoki "build" papka paydo bo'lsa ✅

   SHU PAPKA KERAK! Ichini ochmang!
```

---

## QADAM 2: cPanel'ga yuklash

### **2.1: cPanel'ga kirish**

```
1. Brauzerda oching:
   https://ulugbekedu.uz:2083
   
   (yoki)
   https://ulugbekedu.uz/cpanel

2. Login qiling:
   Username: ulugbeke
   Password: [sizning parolingiz]
```

---

### **2.2: File Manager'ni ochish**

```
1. cPanel dashboard'da qidirish qutisiga
   "File Manager" yozing

2. "File Manager" ni bosing

3. Yangi sahifa ochiladi
```

---

### **2.3: public_html papkasini tozalash**

```
1. Chap tarafda "public_html" ni bosing

2. O'ng tarafda barcha fayllar ko'rinadi

3. BARCHA fayllarni belgilash:
   - Yuqorida checkbox bosing (hammasi belgilanadi)
   
   (Yoki Ctrl+A)

4. Yuqorida "Delete" tugmasini bosing

5. "Confirm" → "Yes"

✅ Papka bo'sh bo'ldi
```

---

### **2.4: Yangi fayllarni yuklash**

**VARIANT A: ZIP orqali (OSON)**

```
1. "dist" yoki "build" papkasini ZIP qiling:
   - Papkaga o'ng tugma → "Send to" → "Compressed folder"
   - dist.zip paydo bo'ladi

2. File Manager'da "Upload" tugmasini bosing

3. "Select File" → dist.zip ni tanlang

4. Yuklash tugaguncha kutish (100%)

5. File Manager'ga qaytish

6. dist.zip ga o'ng tugma → "Extract"

7. Extract manzilini tanlang: /public_html

8. "Extract Files" bosing

9. dist.zip faylni o'chirish mumkin
```

**VARIANT B: To'g'ridan-to'g'ri yuklash**

```
1. "dist" papkasini oching

2. ICHIDAGI barcha fayllarni belgilang

3. File Manager'da "Upload" bosing

4. Fayllarni sudrab tashlang (Drag & Drop)

5. Yuklash tugaguncha kutish
```

---

### **2.5: .htaccess fayl yaratish**

**Bu juda muhim! Ushbu faylsiz sayt ishlamaydi!**

```
1. File Manager'da "public_html" ichida

2. "+ File" tugmasini bosing

3. Fayl nomi: .htaccess

4. "Create New File" bosing

5. .htaccess faylga o'ng tugma → "Edit"

6. Quyidagi kodni to'liq nusxalang:
```

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>

<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/x-javascript
</IfModule>

<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType image/jpg "access plus 1 year"
  ExpiresByType image/jpeg "access plus 1 year"
  ExpiresByType image/gif "access plus 1 year"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType text/css "access plus 1 month"
  ExpiresByType application/pdf "access plus 1 month"
  ExpiresByType text/x-javascript "access plus 1 month"
  ExpiresByType application/x-shockwave-flash "access plus 1 month"
  ExpiresByType image/x-icon "access plus 1 year"
  ExpiresDefault "access plus 2 days"
</IfModule>
```

```
7. "Save Changes" tugmasini bosing

8. Faylni yoping
```

---

### **2.6: Natijani tekshirish**

```
1. Brauzerda yangi tab oching

2. Kiriting: https://ulugbekedu.uz

3. Sayt ko'rinishi kerak! ✅

4. Login qiling:
   Login: admin
   Parol: admin123
```

---

## 🔧 MUAMMOLAR VA YECHIMLAR

### **MUAMMO 1: "404 Not Found"**

**Yechim:**
```
1. .htaccess fayl borligini tekshiring
2. .htaccess kodi to'g'riligini tekshiring
3. Barcha fayllar public_html ichida ekanligini tekshiring
```

---

### **MUAMMO 2: Oq sahifa (bo'sh ekran)**

**Yechim:**
```
1. Brauzerda F12 ni bosing

2. "Console" ga o'ting

3. Qizil xatolarni o'qing

4. Ko'pincha fayl yo'llari muammosi:
   - index.html ni oching
   - <script src="/assets/..."> ko'ring
   - Agar /assets bor bo'lsa, public_html da
     assets papka borligini tekshiring
```

---

### **MUAMMO 3: CSS yuklanmaydi (rangsiz sahifa)**

**Yechim:**
```
1. F12 → Network → Refresh (F5)

2. Qizil fayllarni ko'ring

3. File Manager'da tekshiring:
   - assets papka bor?
   - CSS fayllar bor?

4. Agar yo'q bo'lsa, BUILD qayta qiling
```

---

### **MUAMMO 4: "npm: command not found"**

**Yechim:**
```
1. Node.js o'rnatilganligini tekshiring:
   node -v

2. Agar xato bersa, Node.js ni qayta o'rnating

3. Kompyuterni qayta ishga tushiring

4. Qaytadan urinib ko'ring
```

---

## 📊 TO'G'RI FAYL TUZILISHI

**public_html ichida quyidagilar bo'lishi kerak:**

```
public_html/
├── index.html              ← ASOSIY FAYL
├── assets/                 ← CSS, JS, rasmlar
│   ├── index-abc123.js
│   ├── index-xyz789.css
│   ├── logo.png
│   └── ...
├── .htaccess              ← REACT UCHUN KERAK
├── favicon.ico            ← Ikonka
└── vite.svg               ← (ixtiyoriy)
```

**Agar shu struktura bo'lsa → ✅ TO'G'RI!**

---

## 🎯 QAYSI YO'LNI TANLASH?

| **Omil**              | **VERCEL** | **cPanel** |
|-----------------------|------------|------------|
| Vaqt                  | 5 daqiqa   | 1 soat     |
| Qiyinlik              | ⭐ Oson    | ⭐⭐⭐ Qiyin |
| Texnik bilim          | Kerak emas | Kerak      |
| Xavfsizlik (SSL)      | ✅ Avtomatik | ⚠️ Sozlash |
| Tezlik                | ✅ Juda tez | O'rtacha   |
| Yangilanish           | Avtomatik  | Qo'lda     |
| **MEN TAVSIYA QILAMAN** | **✅ HA!** | ⚠️ Faqat kerak bo'lsa |

---

## ✅ XULOSA

### **AGAR SIZ:**
- ✅ Tez tayyor bo'lishni xohlasangiz
- ✅ Texnik bilan yoqmaydigan bo'lsangiz  
- ✅ Professional xizmat xohlasangiz

### **→ VERCEL ISHLATІNG! (YO'L 1)**

---

### **AGAR SIZ:**
- ⚠️ Texnik bilimga ega bo'lsangiz
- ⚠️ Har narsani o'zingiz boshqarmoqchi bo'lsangiz
- ⚠️ cPanel hostingdan foydalanish kerak bo'lsa

### **→ cPanel ISHLATІNG! (YO'L 2)**

---

## 💡 MASLAHATIM

**MEN SIZGA VERCEL NI TAVSIYA QILAMAN!**

Sabablari:
1. ⏱️ 5 daqiqada tayyor
2. 🚀 Juda tez ishlaydi
3. 🔒 Avtomatik SSL (HTTPS)
4. 💰 Bepul
5. 🎯 Professional
6. 🔄 Avtomatik yangilanish

**Domeningizni (ulugbekedu.uz) Vercel'ga ulash juda oson!**

---

## 📞 YORDAM KERAKMI?

**Video qo'llanmalar:**

1. **Vercel uchun:**
   - YouTube: "how to deploy to vercel"
   - YouTube: "vercel custom domain"

2. **cPanel uchun:**
   - YouTube: "react app cpanel deployment"
   - YouTube: "upload react to cpanel"

**O'zbek tilida:**
   - YouTube: "vebsayt yaratish"
   - YouTube: "hosting sozlash"

---

## 🎉 OMAD!

**Qaysi yo'lni tanlasangiz ham, saytingiz tayyor bo'ladi!**

**Savol bo'lsa, qaytadan so'rang!**

---

**© Mirzo Ulug'bek Maktabi - Moliyaviy Tizim 2024**
