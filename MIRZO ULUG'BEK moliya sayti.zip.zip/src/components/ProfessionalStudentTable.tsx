import { useState, useMemo, useRef } from "react";
import {
  Search,
  Download,
  Filter,
  Users,
  DollarSign,
  AlertCircle,
  CheckCircle2,
  Calendar,
  FileSpreadsheet,
  MoreVertical,
  Eye,
  UserX,
  AlertTriangle,
  Phone,
  MapPin,
  GraduationCap,
  BookOpen,
  Plus,
  CreditCard,
} from "lucide-react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Card } from "./ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Label } from "./ui/label";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Textarea } from "./ui/textarea";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";
import { AddStudentDialog } from "./AddStudentDialog";
import { SetPaymentDialog } from "./SetPaymentDialog";
import { ImportStudentsDialog } from "./ImportStudentsDialog";

// Oylar ro'yxati
const OYLAR = [
  "AVGUST",
  "SENTYABR",
  "OKTYABR",
  "NOYABR",
  "DEKABR",
  "YANVAR",
  "FEVRAL",
  "MART",
  "APREL",
  "MAY",
  "IYUN",
  "IYUL",
];

// Mock ma'lumotlar
const mockStudents = [
  {
    id: 1,
    ism: "Abdurashidova Odina Ahmadali qizi",
    tugilgan: "08.12.2009",
    tuman: "Beshariq",
    manzil: "Rapqon qishlog'i",
    telefon1: "998908502281",
    telefon2: "998912035496",
    sinf: "10",
    fan1: "Kimyo",
    fan2: "Biologiya",
    kelganSana: "01.08.2024",
    oylikTolovlar: {
      AVGUST: 1350000,
      SENTYABR: 1350000,
      OKTYABR: 1350000,
      NOYABR: 1350000,
      DEKABR: null,
      YANVAR: null,
      FEVRAL: null,
      MART: null,
      APREL: null,
      MAY: null,
      IYUN: null,
      IYUL: null,
    },
  },
  {
    id: 2,
    ism: "Nuraliyeva Dilzebo Sanjarbek qizi",
    tugilgan: "04.05.2010",
    tuman: "Pop",
    manzil: "Chorkesar qishlog'i",
    telefon1: "998957946484",
    telefon2: "998772534306",
    sinf: "10",
    fan1: "Kimyo",
    fan2: "Biologiya",
    kelganSana: "01.08.2024",
    oylikTolovlar: {
      AVGUST: 1350000,
      SENTYABR: 1350000,
      OKTYABR: 1350000,
      NOYABR: 1350000,
      DEKABR: null,
      YANVAR: null,
      FEVRAL: null,
      MART: null,
      APREL: null,
      MAY: null,
      IYUN: null,
      IYUL: null,
    },
  },
  {
    id: 3,
    ism: "Tursunaliyeva Nilufar Usmonjon qizi",
    tugilgan: "19.11.2009",
    tuman: "Pop",
    manzil: "Chorkesar qishlog'i",
    telefon1: "998770052786",
    telefon2: "998931595583",
    sinf: "10",
    fan1: "Kimyo",
    fan2: "Biologiya",
    kelganSana: "01.08.2024",
    oylikTolovlar: {
      AVGUST: 1350000,
      SENTYABR: 1350000,
      OKTYABR: 1350000,
      NOYABR: 1350000,
      DEKABR: null,
      YANVAR: null,
      FEVRAL: null,
      MART: null,
      APREL: null,
      MAY: null,
      IYUN: null,
      IYUL: null,
    },
  },
  {
    id: 4,
    ism: "Bahodirova Dilnura Nodirbek qizi",
    tugilgan: "11.02.2008",
    tuman: "Beshariq",
    manzil: "Ariqboshi qishlog'i",
    telefon1: "998950042267",
    telefon2: "998502223508",
    sinf: "11",
    fan1: "Kimyo",
    fan2: "Biologiya",
    kelganSana: "01.08.2024",
    oylikTolovlar: {
      AVGUST: 1350000,
      SENTYABR: 1350000,
      OKTYABR: 1350000,
      NOYABR: 1350000,
      DEKABR: null,
      YANVAR: null,
      FEVRAL: null,
      MART: null,
      APREL: null,
      MAY: null,
      IYUN: null,
      IYUL: null,
    },
  },
  {
    id: 5,
    ism: "Mamadaliyeva Dilnura Botirali qizi",
    tugilgan: "28.07.2010",
    tuman: "Beshariq",
    manzil: "Beshkapa qishlog'i",
    telefon1: "998934077511",
    telefon2: "998931598375",
    sinf: "8",
    fan1: "Ingliz tili",
    fan2: "Tarix",
    kelganSana: "01.08.2024",
    oylikTolovlar: {
      AVGUST: 1350000,
      SENTYABR: 1350000,
      OKTYABR: 1350000,
      NOYABR: 1350000,
      DEKABR: null,
      YANVAR: null,
      FEVRAL: null,
      MART: null,
      APREL: null,
      MAY: null,
      IYUN: null,
      IYUL: null,
    },
  },
];

type Student = (typeof mockStudents)[0];

interface ChetlatilganStudent {
  student: Student;
  sabab: string;
  sana: string;
}

interface JarimadagiStudent {
  student: Student;
  sabab: string;
  summa: number;
  sana: string;
}

export function ProfessionalStudentTable() {
  const [qidiruv, setQidiruv] = useState("");
  const [sinfFilter, setSinfFilter] = useState<string>("all");
  const [tolovFilter, setTolovFilter] = useState<string>("all");
  const [tanlanganOy, setTanlanganOy] =
    useState<string>("DEKABR");
  const [sahifa, setSahifa] = useState(1);
  const sahifaHajmi = 10;
  
  // Scroll ref for payment section
  const qidiruvRef = useRef<HTMLDivElement>(null);

  // Batafsil dialog
  const [batafsilDialog, setBatafsilDialog] = useState(false);
  const [tanlanganStudent, setTanlanganStudent] =
    useState<Student | null>(null);

  // Chetlatish
  const [chetlatishDialog, setChetlatishDialog] =
    useState(false);
  const [chetlatishSabab, setChetlatishSabab] = useState("");
  const [chetlatilganlar, setChetlatilganlar] = useState<
    ChetlatilganStudent[]
  >([]);

  // Jarima
  const [jarimaDialog, setJarimaDialog] = useState(false);
  const [jarimaSabab, setJarimaSabab] = useState("");
  const [jarimaSumma, setJarimaSumma] = useState("");
  const [jarimadagilar, setJarimadagilar] = useState<
    JarimadagiStudent[]
  >([]);

  // Export
  const [exportDialogOpen, setExportDialogOpen] =
    useState(false);
  const [exportOy, setExportOy] = useState<string>("DEKABR");
  const [exportFilter, setExportFilter] =
    useState<string>("all");

  // Tab
  const [activeTab, setActiveTab] = useState("oquvchilar");

  // Faol o'quvchilar (chetlatilmaganlar)
  const faolOquvchilar = useMemo(() => {
    const chetlatilganIds = chetlatilganlar.map(
      (c) => c.student.id,
    );
    return mockStudents.filter(
      (s) => !chetlatilganIds.includes(s.id),
    );
  }, [chetlatilganlar]);

  // Filtrlangan o'quvchilar
  const filteredStudents = useMemo(() => {
    return faolOquvchilar.filter((student) => {
      const ismMatch = student.ism
        .toLowerCase()
        .includes(qidiruv.toLowerCase());
      const sinfMatch =
        sinfFilter === "all" || student.sinf === sinfFilter;

      let tolovMatch = true;
      if (tolovFilter === "toladi") {
        tolovMatch =
          student.oylikTolovlar[
            tanlanganOy as keyof typeof student.oylikTolovlar
          ] !== null;
      } else if (tolovFilter === "qarzdor") {
        tolovMatch =
          student.oylikTolovlar[
            tanlanganOy as keyof typeof student.oylikTolovlar
          ] === null;
      }

      return ismMatch && sinfMatch && tolovMatch;
    });
  }, [
    faolOquvchilar,
    qidiruv,
    sinfFilter,
    tolovFilter,
    tanlanganOy,
  ]);

  // Statistika
  const stats = useMemo(() => {
    const jami = filteredStudents.length;
    const toladi = filteredStudents.filter(
      (s) =>
        s.oylikTolovlar[
          tanlanganOy as keyof typeof s.oylikTolovlar
        ] !== null,
    ).length;
    const qarzdor = jami - toladi;
    const jamiSumma = filteredStudents.reduce((sum, s) => {
      const tolov =
        s.oylikTolovlar[
          tanlanganOy as keyof typeof s.oylikTolovlar
        ];
      return sum + (tolov || 0);
    }, 0);

    return { jami, toladi, qarzdor, jamiSumma };
  }, [filteredStudents, tanlanganOy]);

  // Sahifalash
  const sahifalarSoni = Math.ceil(
    filteredStudents.length / sahifaHajmi,
  );
  const boshlanish = (sahifa - 1) * sahifaHajmi;
  const currentStudents = filteredStudents.slice(
    boshlanish,
    boshlanish + sahifaHajmi,
  );

  // Sinflar ro'yxati
  const sinflar = Array.from(
    new Set(mockStudents.map((s) => s.sinf)),
  ).sort();

  const formatSumma = (summa: number | null) => {
    if (summa === null) return "-";
    return (
      new Intl.NumberFormat("uz-UZ").format(summa) + " so'm"
    );
  };

  const handleBatafsil = (student: Student) => {
    setTanlanganStudent(student);
    setBatafsilDialog(true);
  };

  const handleChetlatishOchish = (student: Student) => {
    setTanlanganStudent(student);
    setChetlatishSabab("");
    setChetlatishDialog(true);
  };

  const handleChetlatish = () => {
    if (tanlanganStudent && chetlatishSabab.trim()) {
      const yangi: ChetlatilganStudent = {
        student: tanlanganStudent,
        sabab: chetlatishSabab,
        sana: new Date().toLocaleDateString("uz-UZ"),
      };
      setChetlatilganlar([...chetlatilganlar, yangi]);
      setChetlatishDialog(false);
      setChetlatishSabab("");
      setTanlanganStudent(null);
    }
  };

  const handleJarimaOchish = (student: Student) => {
    setTanlanganStudent(student);
    setJarimaSabab("");
    setJarimaSumma("");
    setJarimaDialog(true);
  };

  const handleJarima = () => {
    if (tanlanganStudent && jarimaSabab.trim() && jarimaSumma) {
      const yangi: JarimadagiStudent = {
        student: tanlanganStudent,
        sabab: jarimaSabab,
        summa: parseInt(jarimaSumma),
        sana: new Date().toLocaleDateString("uz-UZ"),
      };
      setJarimadagilar([...jarimadagilar, yangi]);
      setJarimaDialog(false);
      setJarimaSabab("");
      setJarimaSumma("");
      setTanlanganStudent(null);
    }
  };

  const handleExport = () => {
    const exportData = faolOquvchilar.filter((student) => {
      const tolov =
        student.oylikTolovlar[
          exportOy as keyof typeof student.oylikTolovlar
        ];

      if (exportFilter === "toladi") {
        return tolov !== null;
      } else if (exportFilter === "qarzdor") {
        return tolov === null;
      }
      return true;
    });

    const headers = [
      "№",
      "ISM FAMILIYA",
      "TUG'ILGAN SANA",
      "TUMAN",
      "MANZIL",
      "TELEFON 1",
      "TELEFON 2",
      "SINF",
      "FAN 1",
      "FAN 2",
      exportOy,
      "HOLAT",
    ];
    const csvContent = [
      headers.join(","),
      ...exportData.map((student, index) => {
        const tolov =
          student.oylikTolovlar[
            exportOy as keyof typeof student.oylikTolovlar
          ];
        const holat = tolov !== null ? "To'ladi" : "Qarzdor";
        const summa = tolov !== null ? tolov : 0;

        return [
          index + 1,
          `"${student.ism}"`,
          student.tugilgan,
          student.tuman,
          `"${student.manzil}"`,
          student.telefon1,
          student.telefon2 || "-",
          student.sinf,
          student.fan1,
          student.fan2,
          summa,
          holat,
        ].join(",");
      }),
    ].join("\n");

    const blob = new Blob(["\uFEFF" + csvContent], {
      type: "text/csv;charset=utf-8;",
    });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);

    const filterText =
      exportFilter === "toladi"
        ? "Tolaganlar"
        : exportFilter === "qarzdor"
          ? "Qarzdorlar"
          : "Barchasi";
    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `Oquvchilar_${exportOy}_${filterText}.csv`,
    );
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setExportDialogOpen(false);
  };
  
  // Scroll to search section when payment is set
  const handlePaymentButtonClick = () => {
    setTimeout(() => {
      qidiruvRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  return (
    <div className="max-w-[1600px] mx-auto p-4 md:p-8 space-y-6">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-lg border border-white/50 p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-slate-900 mb-1">
              O'quvchilar Ma'lumotlar Bazasi
            </h1>
            <p className="text-slate-600">
              To'liq ro'yxat va to'lov hisoboti
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button
              onClick={() => setExportDialogOpen(true)}
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-lg rounded-xl"
            >
              <FileSpreadsheet className="size-4 mr-2" />
              Excel ga eksport
            </Button>
            <ImportStudentsDialog />
            <AddStudentDialog />
            <div onClick={handlePaymentButtonClick}>
              <SetPaymentDialog />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs
        value={activeTab}
        onValueChange={setActiveTab}
        className="space-y-6"
      >
        <TabsList className="bg-white/80 backdrop-blur-xl border border-white/50 p-1 rounded-xl">
          <TabsTrigger
            value="oquvchilar"
            className="rounded-lg data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-indigo-600 data-[state=active]:text-white"
          >
            <Users className="size-4 mr-2" />
            O'quvchilar ({stats.jami})
          </TabsTrigger>
          <TabsTrigger
            value="chetlatilganlar"
            className="rounded-lg data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-rose-600 data-[state=active]:text-white"
          >
            <UserX className="size-4 mr-2" />
            Chetlatilganlar ({chetlatilganlar.length})
          </TabsTrigger>
          <TabsTrigger
            value="jarimadagilar"
            className="rounded-lg data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-600 data-[state=active]:to-amber-600 data-[state=active]:text-white"
          >
            <AlertTriangle className="size-4 mr-2" />
            Jarimadagilar ({jarimadagilar.length})
          </TabsTrigger>
        </TabsList>

        {/* O'quvchilar Tab */}
        <TabsContent value="oquvchilar" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden group">
              <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-white/20 p-3 rounded-xl backdrop-blur-xl group-hover:rotate-12 group-hover:scale-110 transition-all duration-300">
                    <Users className="size-6" />
                  </div>
                </div>
                <p className="text-blue-100 text-sm mb-1">
                  Jami O'quvchilar
                </p>
                <p className="text-3xl">{stats.jami}</p>
              </div>
            </Card>

            <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white p-6 border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden group">
              <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-white/20 p-3 rounded-xl backdrop-blur-xl group-hover:rotate-12 group-hover:scale-110 transition-all duration-300">
                    <CheckCircle2 className="size-6" />
                  </div>
                </div>
                <p className="text-green-100 text-sm mb-1">
                  To'lov Qilgan
                </p>
                <p className="text-3xl">{stats.toladi}</p>
              </div>
            </Card>

            <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white p-6 border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden group">
              <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-white/20 p-3 rounded-xl backdrop-blur-xl group-hover:rotate-12 group-hover:scale-110 transition-all duration-300">
                    <AlertCircle className="size-6" />
                  </div>
                </div>
                <p className="text-red-100 text-sm mb-1">Qarzdorlar</p>
                <p className="text-3xl">{stats.qarzdor}</p>
              </div>
            </Card>

            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-6 border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden group">
              <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-white/20 p-3 rounded-xl backdrop-blur-xl group-hover:rotate-12 group-hover:scale-110 transition-all duration-300">
                    <DollarSign className="size-6" />
                  </div>
                </div>
                <p className="text-purple-100 text-sm mb-1">
                  Jami To'lov
                </p>
                <p className="text-2xl">{formatSumma(stats.jamiSumma)}</p>
              </div>
            </Card>
          </div>

          {/* Filters */}
          <div ref={qidiruvRef} className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-lg border border-white/50 p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-slate-400" />
                <Input
                  placeholder="O'quvchini qidirish (ism, familiya)..."
                  value={qidiruv}
                  onChange={(e) => setQidiruv(e.target.value)}
                  className="pl-10 bg-white border-slate-200 h-11"
                />
              </div>

              <Select
                value={sinfFilter}
                onValueChange={setSinfFilter}
              >
                <SelectTrigger className="w-full lg:w-40 bg-white border-slate-200">
                  <Filter className="size-4 mr-2 text-slate-400" />
                  <SelectValue placeholder="Sinf" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Barcha sinflar</SelectItem>
                  {sinflar.map((sinf) => (
                    <SelectItem key={sinf} value={sinf}>
                      {sinf}-sinf
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={tolovFilter}
                onValueChange={setTolovFilter}
              >
                <SelectTrigger className="w-full lg:w-40 bg-white border-slate-200">
                  <Filter className="size-4 mr-2 text-slate-400" />
                  <SelectValue placeholder="To'lov holati" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Barchasi</SelectItem>
                  <SelectItem value="toladi">
                    To'ladi
                  </SelectItem>
                  <SelectItem value="qarzdor">
                    Qarzdor
                  </SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={tanlanganOy}
                onValueChange={setTanlanganOy}
              >
                <SelectTrigger className="w-full lg:w-40 bg-white border-slate-200">
                  <Calendar className="size-4 mr-2 text-slate-400" />
                  <SelectValue placeholder="Oy tanlang" />
                </SelectTrigger>
                <SelectContent>
                  {OYLAR.map((oy) => (
                    <SelectItem key={oy} value={oy}>
                      {oy}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Jadval */}
          <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-lg border border-white/50 overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gradient-to-r from-slate-50 to-slate-100 border-slate-200">
                    <TableHead className="text-slate-900 w-12">
                      №
                    </TableHead>
                    <TableHead className="text-slate-900 min-w-[250px]">
                      ISM FAMILIYA
                    </TableHead>
                    <TableHead className="text-slate-900">
                      TUG'ILGAN
                    </TableHead>
                    <TableHead className="text-slate-900">
                      SINF
                    </TableHead>
                    <TableHead className="text-slate-900">
                      YO'NALISH (FAN 1)
                    </TableHead>
                    <TableHead className="text-slate-900">
                      FAN 2
                    </TableHead>
                    <TableHead className="text-slate-900">
                      {tanlanganOy}
                    </TableHead>
                    <TableHead className="text-slate-900">
                      TO'LOV
                    </TableHead>
                    <TableHead className="text-slate-900 text-right">
                      AMAL
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {currentStudents.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={9}
                        className="text-center text-slate-500 h-32"
                      >
                        Ma'lumot topilmadi
                      </TableCell>
                    </TableRow>
                  ) : (
                    currentStudents.map((student, index) => {
                      const oylikTolov =
                        student.oylikTolovlar[
                          tanlanganOy as keyof typeof student.oylikTolovlar
                        ];
                      const toladi = oylikTolov !== null;

                      return (
                        <TableRow
                          key={student.id}
                          className="border-slate-200 hover:bg-gradient-to-r hover:from-blue-50/30 hover:to-purple-50/30 transition-all duration-200"
                        >
                          <TableCell className="py-4">
                            <span className="bg-slate-100 px-3 py-1 rounded-lg text-slate-700">
                              {boshlanish + index + 1}
                            </span>
                          </TableCell>
                          <TableCell className="text-slate-900 py-4">
                            {student.ism}
                          </TableCell>
                          <TableCell className="text-slate-600 py-4">
                            {student.tugilgan}
                          </TableCell>
                          <TableCell className="py-4">
                            <Badge
                              variant="outline"
                              className="bg-blue-50 text-blue-700 border-blue-200"
                            >
                              {student.sinf}
                            </Badge>
                          </TableCell>
                          <TableCell className="py-4">
                            <Badge
                              variant="outline"
                              className="bg-purple-50 text-purple-700 border-purple-200"
                            >
                              {student.fan1}
                            </Badge>
                          </TableCell>
                          <TableCell className="py-4">
                            <Badge
                              variant="outline"
                              className="bg-indigo-50 text-indigo-700 border-indigo-200"
                            >
                              {student.fan2}
                            </Badge>
                          </TableCell>
                          <TableCell className="py-4">
                            <span
                              className={
                                oylikTolov
                                  ? "text-green-700"
                                  : "text-slate-400"
                              }
                            >
                              {formatSumma(oylikTolov)}
                            </span>
                          </TableCell>
                          <TableCell className="py-4">
                            {toladi ? (
                              <Badge className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0 shadow-md">
                                ✓ To'ladi
                              </Badge>
                            ) : (
                              <Badge className="bg-gradient-to-r from-red-500 to-red-600 text-white border-0 shadow-md">
                                ✗ Qarzdor
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right py-4">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="hover:bg-blue-50"
                                >
                                  <MoreVertical className="size-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() =>
                                    handleBatafsil(student)
                                  }
                                >
                                  <Eye className="size-4 mr-2" />
                                  Batafsil
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() =>
                                    handleChetlatishOchish(student)
                                  }
                                  className="text-red-600 focus:text-red-600"
                                >
                                  <UserX className="size-4 mr-2" />
                                  Chetlatish
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() =>
                                    handleJarimaOchish(student)
                                  }
                                  className="text-orange-600 focus:text-orange-600"
                                >
                                  <AlertTriangle className="size-4 mr-2" />
                                  Jarima
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            <div className="border-t border-slate-200 bg-slate-50/50 px-6 py-4">
              <div className="flex items-center justify-between">
                <p className="text-slate-600 text-sm">
                  Jami {filteredStudents.length} ta o'quvchi
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      setSahifa((prev) => Math.max(prev - 1, 1))
                    }
                    disabled={sahifa === 1}
                    className="bg-white hover:bg-slate-50 border-slate-200"
                  >
                    Oldingi
                  </Button>
                  <div className="flex gap-1">
                    {Array.from(
                      { length: sahifalarSoni },
                      (_, i) => i + 1,
                    ).map((pageNum) => {
                      if (
                        pageNum === 1 ||
                        pageNum === sahifalarSoni ||
                        Math.abs(pageNum - sahifa) <= 1
                      ) {
                        return (
                          <Button
                            key={pageNum}
                            size="sm"
                            variant={
                              sahifa === pageNum
                                ? "default"
                                : "outline"
                            }
                            onClick={() => setSahifa(pageNum)}
                            className={
                              sahifa === pageNum
                                ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white"
                                : "bg-white hover:bg-slate-50 border-slate-200"
                            }
                          >
                            {pageNum}
                          </Button>
                        );
                      } else if (
                        Math.abs(pageNum - sahifa) === 2
                      ) {
                        return (
                          <span
                            key={pageNum}
                            className="px-2 text-slate-400"
                          >
                            ...
                          </span>
                        );
                      }
                      return null;
                    })}
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      setSahifa((prev) =>
                        Math.min(prev + 1, sahifalarSoni),
                      )
                    }
                    disabled={sahifa === sahifalarSoni}
                    className="bg-white hover:bg-slate-50 border-slate-200"
                  >
                    Keyingi
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Chetlatilganlar Tab */}
        <TabsContent value="chetlatilganlar">
          <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-lg border border-white/50 p-6">
            <h2 className="text-red-600 mb-4 flex items-center gap-2">
              <UserX className="size-5" />
              Chetlatilgan O'quvchilar
            </h2>
            {chetlatilganlar.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                Hozircha chetlatilgan o'quvchilar yo'q
              </div>
            ) : (
              <div className="space-y-4">
                {chetlatilganlar.map((item, index) => (
                  <Card
                    key={index}
                    className="p-4 border-red-200 bg-red-50/50"
                  >
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <h3 className="text-slate-900">
                          {item.student.ism}
                        </h3>
                        <p className="text-slate-600">
                          Sinf: {item.student.sinf}
                        </p>
                        <div className="bg-white p-3 rounded-lg border border-red-200">
                          <p className="text-red-700">
                            <strong>Sabab:</strong> {item.sabab}
                          </p>
                        </div>
                        <p className="text-slate-500">
                          Sana: {item.sana}
                        </p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-red-100 text-red-700 border-red-300"
                      >
                        Chetlatilgan
                      </Badge>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Jarimadagilar Tab */}
        <TabsContent value="jarimadagilar">
          <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-lg border border-white/50 p-6">
            <h2 className="text-orange-600 mb-4 flex items-center gap-2">
              <AlertTriangle className="size-5" />
              Jarimadagi O'quvchilar
            </h2>
            {jarimadagilar.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                Hozircha jarimadagi o'quvchilar yo'q
              </div>
            ) : (
              <div className="space-y-4">
                {jarimadagilar.map((item, index) => (
                  <Card
                    key={index}
                    className="p-4 border-orange-200 bg-orange-50/50"
                  >
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <h3 className="text-slate-900">
                          {item.student.ism}
                        </h3>
                        <p className="text-slate-600">
                          Sinf: {item.student.sinf}
                        </p>
                        <div className="bg-white p-3 rounded-lg border border-orange-200">
                          <p className="text-orange-700">
                            <strong>Sabab:</strong> {item.sabab}
                          </p>
                          <p className="text-orange-700 mt-1">
                            <strong>Jarima summasi:</strong>{" "}
                            {formatSumma(item.summa)}
                          </p>
                        </div>
                        <p className="text-slate-500">
                          Sana: {item.sana}
                        </p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-orange-100 text-orange-700 border-orange-300"
                      >
                        Jarimada
                      </Badge>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Batafsil Dialog */}
      <Dialog
        open={batafsilDialog}
        onOpenChange={setBatafsilDialog}
      >
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-slate-900">
              O'quvchi Haqida To'liq Ma'lumot
            </DialogTitle>
            <DialogDescription className="text-slate-600">
              O'quvchining barcha ma'lumotlari va oylik
              to'lovlar tarixi
            </DialogDescription>
          </DialogHeader>
          {tanlanganStudent && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-slate-600">
                    ISM FAMILIYA
                  </Label>
                  <p className="text-slate-900">
                    {tanlanganStudent.ism}
                  </p>
                </div>
                <div className="space-y-1">
                  <Label className="text-slate-600">
                    TUG'ILGAN SANA
                  </Label>
                  <p className="text-slate-900">
                    {tanlanganStudent.tugilgan}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-slate-600 flex items-center gap-1">
                    <MapPin className="size-4" /> TUMAN
                  </Label>
                  <Badge
                    variant="outline"
                    className="bg-indigo-50 text-indigo-700 border-indigo-200"
                  >
                    {tanlanganStudent.tuman}
                  </Badge>
                </div>
                <div className="space-y-1">
                  <Label className="text-slate-600 flex items-center gap-1">
                    <GraduationCap className="size-4" /> SINF
                  </Label>
                  <Badge
                    variant="outline"
                    className="bg-blue-50 text-blue-700 border-blue-200"
                  >
                    {tanlanganStudent.sinf}
                  </Badge>
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-slate-600 flex items-center gap-1">
                  <MapPin className="size-4" /> MANZIL
                </Label>
                <p className="text-slate-900">
                  {tanlanganStudent.manzil}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-slate-600 flex items-center gap-1">
                    <Phone className="size-4" /> TELEFON 1
                  </Label>
                  <p className="text-slate-900">
                    +{tanlanganStudent.telefon1}
                  </p>
                </div>
                <div className="space-y-1">
                  <Label className="text-slate-600 flex items-center gap-1">
                    <Phone className="size-4" /> TELEFON 2
                  </Label>
                  <p className="text-slate-900">
                    {tanlanganStudent.telefon2
                      ? `+${tanlanganStudent.telefon2}`
                      : "-"}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-slate-600 flex items-center gap-1">
                    <BookOpen className="size-4" /> YO'NALISH (FAN 1)
                  </Label>
                  <Badge
                    variant="outline"
                    className="bg-purple-50 text-purple-700 border-purple-200"
                  >
                    {tanlanganStudent.fan1}
                  </Badge>
                </div>
                <div className="space-y-1">
                  <Label className="text-slate-600 flex items-center gap-1">
                    <BookOpen className="size-4" /> FAN 2
                  </Label>
                  <Badge
                    variant="outline"
                    className="bg-indigo-50 text-indigo-700 border-indigo-200"
                  >
                    {tanlanganStudent.fan2}
                  </Badge>
                </div>
              </div>

              <div className="border-t pt-4">
                <Label className="text-slate-900 mb-3 block">
                  Oylik To'lovlar Tarixi
                </Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {OYLAR.map((oy) => {
                    const tolov =
                      tanlanganStudent.oylikTolovlar[
                        oy as keyof typeof tanlanganStudent.oylikTolovlar
                      ];
                    const tolandi = tolov !== null;

                    return (
                      <div
                        key={oy}
                        className={`p-3 rounded-xl border ${
                          tolandi
                            ? "bg-green-50 border-green-200"
                            : "bg-slate-50 border-slate-200"
                        }`}
                      >
                        <p className="text-slate-600 text-xs mb-1">
                          {oy}
                        </p>
                        <p
                          className={`text-sm ${
                            tolandi
                              ? "text-green-700"
                              : "text-slate-400"
                          }`}
                        >
                          {formatSumma(tolov)}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Chetlatish Dialog */}
      <Dialog
        open={chetlatishDialog}
        onOpenChange={setChetlatishDialog}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-red-600">
              O'quvchini Chetlatish
            </DialogTitle>
            <DialogDescription>
              O'quvchini chetlatish sababini kiriting
            </DialogDescription>
          </DialogHeader>
          {tanlanganStudent && (
            <div className="space-y-4 py-4">
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-slate-900">
                  {tanlanganStudent.ism}
                </p>
                <p className="text-slate-600 text-sm">
                  Sinf: {tanlanganStudent.sinf}
                </p>
              </div>
              <div>
                <Label>Chetlatish sababi</Label>
                <Textarea
                  value={chetlatishSabab}
                  onChange={(e) =>
                    setChetlatishSabab(e.target.value)
                  }
                  placeholder="Sababi..."
                  className="bg-white border-red-200 mt-1"
                />
              </div>
            </div>
          )}
          <div className="flex gap-3 justify-end">
            <Button
              variant="outline"
              onClick={() => setChetlatishDialog(false)}
            >
              Bekor qilish
            </Button>
            <Button
              onClick={handleChetlatish}
              disabled={!chetlatishSabab.trim()}
              className="bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white"
            >
              <UserX className="size-4 mr-2" />
              Chetlatish
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Jarima Dialog */}
      <Dialog open={jarimaDialog} onOpenChange={setJarimaDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-orange-600">
              Jarima Solish
            </DialogTitle>
            <DialogDescription>
              O'quvchiga jarima solish sababini va summasini
              kiriting
            </DialogDescription>
          </DialogHeader>
          {tanlanganStudent && (
            <div className="space-y-4 py-4">
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-slate-900">
                  {tanlanganStudent.ism}
                </p>
                <p className="text-slate-600 text-sm">
                  Sinf: {tanlanganStudent.sinf}
                </p>
              </div>
              <div>
                <Label>Jarima sababi</Label>
                <Textarea
                  value={jarimaSabab}
                  onChange={(e) => setJarimaSabab(e.target.value)}
                  placeholder="Sababi..."
                  className="bg-white border-orange-200 mt-1"
                />
              </div>
              <div>
                <Label>Jarima summasi (so'm)</Label>
                <Input
                  type="number"
                  value={jarimaSumma}
                  onChange={(e) => setJarimaSumma(e.target.value)}
                  placeholder="500000"
                  className="bg-white border-orange-200 mt-1"
                />
              </div>
            </div>
          )}
          <div className="flex gap-3 justify-end">
            <Button
              variant="outline"
              onClick={() => setJarimaDialog(false)}
            >
              Bekor qilish
            </Button>
            <Button
              onClick={handleJarima}
              disabled={
                !jarimaSabab.trim() || !jarimaSumma
              }
              className="bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white"
            >
              <AlertTriangle className="size-4 mr-2" />
              Jarima solish
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Export Dialog */}
      <Dialog
        open={exportDialogOpen}
        onOpenChange={setExportDialogOpen}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-green-600 flex items-center gap-2">
              <FileSpreadsheet className="size-5" />
              Excel ga Eksport Qilish
            </DialogTitle>
            <DialogDescription>
              Eksport qilish uchun oy va filtrni tanlang
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label>Oy</Label>
              <Select value={exportOy} onValueChange={setExportOy}>
                <SelectTrigger className="bg-white border-green-200 mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {OYLAR.map((oy) => (
                    <SelectItem key={oy} value={oy}>
                      {oy}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Filtr</Label>
              <RadioGroup
                value={exportFilter}
                onValueChange={setExportFilter}
                className="mt-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="all" id="all" />
                  <Label htmlFor="all" className="cursor-pointer">
                    Barcha o'quvchilar
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="toladi" id="toladi" />
                  <Label
                    htmlFor="toladi"
                    className="cursor-pointer"
                  >
                    Faqat to'laganlar
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem
                    value="qarzdor"
                    id="qarzdor"
                  />
                  <Label
                    htmlFor="qarzdor"
                    className="cursor-pointer"
                  >
                    Faqat qarzdorlar
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </div>
          <div className="flex gap-3 justify-end">
            <Button
              variant="outline"
              onClick={() => setExportDialogOpen(false)}
            >
              Bekor qilish
            </Button>
            <Button
              onClick={handleExport}
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white"
            >
              <Download className="size-4 mr-2" />
              Eksport qilish
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
