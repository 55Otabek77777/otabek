import { Plus, MapPin } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

const mockRegions = [
  { id: 1, nom: "Beshariq", oquvchi: 28 },
  { id: 2, nom: "Pop", oquvchi: 32 },
  { id: 3, nom: "Uchko'prik", oquvchi: 25 },
  { id: 4, nom: "Mingbuloq", oquvchi: 18 },
  { id: 5, nom: "Bog'dod", oquvchi: 12 },
  { id: 6, nom: "Buvayda", oquvchi: 10 },
];

export function RegionsModule() {
  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-2xl rounded-3xl shadow-lg border border-white/50 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-slate-900 mb-1">Hududlar</h1>
            <p className="text-slate-600">Hududlar ro'yxati va boshqaruvi</p>
          </div>
          <Button className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white shadow-lg rounded-xl">
            <Plus className="size-4 mr-2" />
            Yangi hudud
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockRegions.map((hudud) => (
            <Card key={hudud.id} className="p-6 bg-gradient-to-br from-cyan-500 to-blue-500 text-white hover:shadow-2xl transition-all duration-300 hover:scale-105 rounded-3xl cursor-pointer group relative overflow-hidden">
              <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              <div className="relative z-10">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-14 h-14 bg-white/20 backdrop-blur-xl rounded-2xl flex items-center justify-center group-hover:rotate-12 group-hover:scale-110 transition-all">
                    <MapPin className="size-7" />
                  </div>
                  <Badge className="bg-white/20 border-white/30 backdrop-blur-xl text-white">
                    {hudud.oquvchi} o'quvchi
                  </Badge>
                </div>
                <h3 className="text-xl mb-2 group-hover:translate-x-1 transition-transform">{hudud.nom}</h3>
                <div className="h-1 w-16 bg-white/30 rounded-full group-hover:w-full transition-all duration-500"></div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
