import { motion } from "motion/react";
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  DollarSign,
  BookOpen,
  School,
  MapPin,
  Settings,
  LogOut,
} from "lucide-react";

interface SidebarProps {
  activePage: string;
  onNavigate: (page: string) => void;
}

const menuItems = [
  { id: "dashboard", icon: LayoutDashboard, label: "Dashboard", color: "from-blue-500 to-cyan-500" },
  { id: "students", icon: Users, label: "O'quvchilar", color: "from-purple-500 to-pink-500" },
  { id: "teachers", icon: GraduationCap, label: "O'qituvchilar", color: "from-green-500 to-emerald-500" },
  { id: "payments", icon: DollarSign, label: "To'lovlar", color: "from-yellow-500 to-orange-500" },
  { id: "subjects", icon: BookOpen, label: "Fanlar", color: "from-red-500 to-rose-500" },
  { id: "classes", icon: School, label: "Sinflar", color: "from-indigo-500 to-purple-500" },
  { id: "regions", icon: MapPin, label: "Hududlar", color: "from-teal-500 to-cyan-500" },
  { id: "settings", icon: Settings, label: "Sozlamalar", color: "from-slate-500 to-gray-500" },
];

export function Sidebar({ activePage, onNavigate }: SidebarProps) {
  return (
    <div className="fixed left-0 top-0 h-screen w-64 bg-white/80 backdrop-blur-2xl border-r border-white/50 shadow-2xl z-50">
      {/* Logo */}
      <div className="p-6 border-b border-slate-200/50">
        <motion.div
          className="flex items-center gap-3"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-xl shadow-lg">
            <GraduationCap className="size-6 text-white" />
          </div>
          <div>
            <h2 className="text-slate-900 text-sm">Mirzo Ulug'bek</h2>
            <p className="text-slate-600 text-xs">Xususiy Maktabi</p>
          </div>
        </motion.div>
      </div>

      {/* Menu items */}
      <nav className="p-4 space-y-2">
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;

          return (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => onNavigate(item.id)}
              className="w-full group relative"
            >
              {/* Active indicator */}
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className={`absolute inset-0 bg-gradient-to-r ${item.color} rounded-xl opacity-10`}
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}

              <div
                className={`relative flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                  isActive
                    ? "text-slate-900"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100/50"
                }`}
              >
                {/* Icon with gradient background */}
                <motion.div
                  className={`p-2 rounded-lg ${
                    isActive
                      ? `bg-gradient-to-r ${item.color}`
                      : "bg-slate-100 group-hover:bg-slate-200"
                  } transition-all duration-300`}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Icon
                    className={`size-5 ${
                      isActive ? "text-white" : "text-slate-600"
                    }`}
                  />
                </motion.div>

                <span className={isActive ? "" : ""}>{item.label}</span>

                {/* Liquid effect on hover */}
                {!isActive && (
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-r ${item.color} rounded-xl opacity-0 group-hover:opacity-5`}
                    initial={{ scale: 0 }}
                    whileHover={{ scale: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                )}
              </div>
            </motion.button>
          );
        })}
      </nav>

      {/* Logout button */}
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-200/50">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-gradient-to-r from-red-500 to-rose-500 text-white hover:from-red-600 hover:to-rose-600 transition-all shadow-lg group"
        >
          <motion.div
            whileHover={{ rotate: 180 }}
            transition={{ duration: 0.3 }}
          >
            <LogOut className="size-5" />
          </motion.div>
          <span>Chiqish</span>
        </motion.button>
      </div>
    </div>
  );
}
