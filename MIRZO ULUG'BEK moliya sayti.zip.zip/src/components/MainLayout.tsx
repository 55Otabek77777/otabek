import { useState } from "react";
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  BookOpen, 
  School,
  MapPin,
  DollarSign,
  LogOut,
  Menu,
  X,
  ChevronRight
} from "lucide-react";
import { Button } from "./ui/button";
import { Dashboard } from "./Dashboard";
import { ProfessionalStudentTable } from "./ProfessionalStudentTable";
import { TeachersModule } from "./TeachersModule";
import { SubjectsModule } from "./SubjectsModule";
import { ClassesModule } from "./ClassesModule";
import { RegionsModule } from "./RegionsModule";
import { PaymentsModule } from "./PaymentsModule";
import logoImage from "figma:asset/2f48f3791ecd205478f12f766bf06a64507cd70c.png";
import { TashkentClock } from "./TashkentClock";

interface MainLayoutProps {
  onLogout: () => void;
}

type Page = "dashboard" | "students" | "teachers" | "subjects" | "classes" | "regions" | "payments";

export function MainLayout({ onLogout }: MainLayoutProps) {
  const [currentPage, setCurrentPage] = useState<Page>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const menuItems = [
    { id: "dashboard" as Page, label: "Dashboard", icon: LayoutDashboard, color: "from-blue-500 to-blue-600" },
    { id: "students" as Page, label: "O'quvchilar", icon: GraduationCap, color: "from-green-500 to-green-600" },
    { id: "teachers" as Page, label: "O'qituvchilar", icon: Users, color: "from-purple-500 to-purple-600" },
    { id: "subjects" as Page, label: "Yo'nalishlar", icon: BookOpen, color: "from-orange-500 to-orange-600" },
    { id: "classes" as Page, label: "Sinflar", icon: School, color: "from-pink-500 to-pink-600" },
    { id: "regions" as Page, label: "Hududlar", icon: MapPin, color: "from-cyan-500 to-cyan-600" },
    { id: "payments" as Page, label: "To'lovlar", icon: DollarSign, color: "from-emerald-500 to-emerald-600" },
  ];

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <Dashboard />;
      case "students":
        return <ProfessionalStudentTable />;
      case "teachers":
        return <TeachersModule />;
      case "subjects":
        return <SubjectsModule />;
      case "classes":
        return <ClassesModule />;
      case "regions":
        return <RegionsModule />;
      case "payments":
        return <PaymentsModule />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 z-40 h-screen transition-all duration-300 ${
          sidebarOpen ? "w-72" : "w-20"
        }`}
      >
        <div className="h-full bg-white/80 backdrop-blur-2xl border-r border-white/50 shadow-xl">
          {/* Header */}
          <div className="p-6 border-b border-white/50">
            <div className="flex items-center justify-between">
              {sidebarOpen && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-lg animate-spin-slow">
                    <img 
                      src={logoImage} 
                      alt="Mirzo Ulug'bek Logo" 
                      className="w-8 h-8 object-contain"
                    />
                  </div>
                  <div>
                    <h2 className="text-slate-900 text-sm">Mirzo Ulug'bek</h2>
                    <p className="text-slate-500 text-xs">Xususiy Maktabi</p>
                  </div>
                </div>
              )}
              {!sidebarOpen && (
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-lg animate-spin-slow mx-auto">
                  <img 
                    src={logoImage} 
                    alt="Mirzo Ulug'bek Logo" 
                    className="w-8 h-8 object-contain"
                  />
                </div>
              )}
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="hover:bg-blue-50 rounded-xl"
              >
                {sidebarOpen ? <X className="size-5" /> : <Menu className="size-5" />}
              </Button>
            </div>
          </div>

          {/* Toshkent Vaqti */}
          {sidebarOpen && (
            <div className="p-4">
              <TashkentClock />
            </div>
          )}

          {/* Navigation */}
          <nav className="p-4 space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentPage(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 group relative overflow-hidden ${
                    isActive
                      ? `bg-gradient-to-r ${item.color} text-white shadow-lg scale-105`
                      : "hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 text-slate-600 hover:text-slate-900"
                  }`}
                >
                  {isActive && (
                    <div className="absolute inset-0 bg-white/20 animate-pulse-slow"></div>
                  )}
                  <Icon className={`size-5 relative z-10 ${isActive ? "animate-bounce-subtle" : "group-hover:scale-110 transition-transform"}`} />
                  {sidebarOpen && (
                    <>
                      <span className="relative z-10 flex-1 text-left">{item.label}</span>
                      {isActive && <ChevronRight className="size-4 relative z-10 animate-pulse" />}
                    </>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Logout */}
          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/50">
            <Button
              onClick={onLogout}
              variant="ghost"
              className="w-full flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 hover:text-red-700 rounded-xl transition-all duration-300 group"
            >
              <LogOut className="size-5 group-hover:-translate-x-1 transition-transform" />
              {sidebarOpen && <span>Chiqish</span>}
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main
        className={`transition-all duration-300 ${
          sidebarOpen ? "ml-72" : "ml-20"
        }`}
      >
        <div className="p-8">
          {renderPage()}
        </div>
      </main>
    </div>
  );
}
