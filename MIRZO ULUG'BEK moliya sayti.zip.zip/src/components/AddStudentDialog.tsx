import { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

export function AddStudentDialog() {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    ism: "",
    tugilgan: "",
    tuman: "",
    manzil: "",
    telefon1: "",
    telefon2: "",
    sinf: "",
    fan1: "",
    fan2: "",
  });

  const handleSubmit = () => {
    console.log("Yangi o'quvchi:", formData);
    alert("O'quvchi muvaffaqiyatli qo'shildi!");
    setOpen(false);
    // Reset form
    setFormData({
      ism: "",
      tugilgan: "",
      tuman: "",
      manzil: "",
      telefon1: "",
      telefon2: "",
      sinf: "",
      fan1: "",
      fan2: "",
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-lg rounded-xl">
          <Plus className="size-4 mr-2" />
          Yangi o'quvchi
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-green-600">Yangi O'quvchi Qo'shish</DialogTitle>
          <DialogDescription>
            O'quvchining barcha ma'lumotlarini to'liq kiriting
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Label>ISM FAMILIYA</Label>
              <Input
                value={formData.ism}
                onChange={(e) => setFormData({ ...formData, ism: e.target.value })}
                placeholder="Abdurashidova Odina Ahmadali qizi"
                className="bg-white border-green-200 rounded-xl"
              />
            </div>

            <div>
              <Label>TUG'ILGAN SANA</Label>
              <Input
                type="date"
                value={formData.tugilgan}
                onChange={(e) => setFormData({ ...formData, tugilgan: e.target.value })}
                className="bg-white border-green-200 rounded-xl"
              />
            </div>

            <div>
              <Label>SINF</Label>
              <Select value={formData.sinf} onValueChange={(val) => setFormData({ ...formData, sinf: val })}>
                <SelectTrigger className="bg-white border-green-200 rounded-xl">
                  <SelectValue placeholder="Tanlang..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="8">8-sinf</SelectItem>
                  <SelectItem value="9">9-sinf</SelectItem>
                  <SelectItem value="10">10-sinf</SelectItem>
                  <SelectItem value="11">11-sinf</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>TUMAN</Label>
              <Select value={formData.tuman} onValueChange={(val) => setFormData({ ...formData, tuman: val })}>
                <SelectTrigger className="bg-white border-green-200 rounded-xl">
                  <SelectValue placeholder="Tanlang..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Beshariq">Beshariq</SelectItem>
                  <SelectItem value="Pop">Pop</SelectItem>
                  <SelectItem value="Uchko'prik">Uchko'prik</SelectItem>
                  <SelectItem value="Mingbuloq">Mingbuloq</SelectItem>
                  <SelectItem value="Bog'dod">Bog'dod</SelectItem>
                  <SelectItem value="Buvayda">Buvayda</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>MANZIL</Label>
              <Input
                value={formData.manzil}
                onChange={(e) => setFormData({ ...formData, manzil: e.target.value })}
                placeholder="Rapqon qishlog'i"
                className="bg-white border-green-200 rounded-xl"
              />
            </div>

            <div>
              <Label>TELEFON 1</Label>
              <Input
                value={formData.telefon1}
                onChange={(e) => setFormData({ ...formData, telefon1: e.target.value })}
                placeholder="998901234567"
                className="bg-white border-green-200 rounded-xl"
              />
            </div>

            <div>
              <Label>TELEFON 2 (ixtiyoriy)</Label>
              <Input
                value={formData.telefon2}
                onChange={(e) => setFormData({ ...formData, telefon2: e.target.value })}
                placeholder="998907654321"
                className="bg-white border-green-200 rounded-xl"
              />
            </div>

            <div>
              <Label>YO'NALISH (FAN 1)</Label>
              <Select value={formData.fan1} onValueChange={(val) => setFormData({ ...formData, fan1: val })}>
                <SelectTrigger className="bg-white border-green-200 rounded-xl">
                  <SelectValue placeholder="Tanlang..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Matematika">Matematika</SelectItem>
                  <SelectItem value="Fizika">Fizika</SelectItem>
                  <SelectItem value="Kimyo">Kimyo</SelectItem>
                  <SelectItem value="Biologiya">Biologiya</SelectItem>
                  <SelectItem value="Ingliz tili">Ingliz tili</SelectItem>
                  <SelectItem value="Tarix">Tarix</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>FAN 2</Label>
              <Select value={formData.fan2} onValueChange={(val) => setFormData({ ...formData, fan2: val })}>
                <SelectTrigger className="bg-white border-green-200 rounded-xl">
                  <SelectValue placeholder="Tanlang..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Matematika">Matematika</SelectItem>
                  <SelectItem value="Fizika">Fizika</SelectItem>
                  <SelectItem value="Kimyo">Kimyo</SelectItem>
                  <SelectItem value="Biologiya">Biologiya</SelectItem>
                  <SelectItem value="Ingliz tili">Ingliz tili</SelectItem>
                  <SelectItem value="Tarix">Tarix</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={() => setOpen(false)}>
            Bekor qilish
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={!formData.ism || !formData.sinf || !formData.fan1 || !formData.fan2}
            className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white"
          >
            <Plus className="size-4 mr-2" />
            Saqlash
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
