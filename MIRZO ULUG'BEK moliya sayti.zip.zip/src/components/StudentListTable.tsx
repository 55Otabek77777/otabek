import { useState, useMemo } from "react";
import { Search, Edit2, Trash2, ChevronLeft, ChevronRight } from "lucide-react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";

// Mock ma'lumotlar
const mockStudents = [
  { id: 1, ism: "Alisher Navoiy", sinf: "10-A", telefon: "+998 90 123 45 67", tolov: "To'ladi", summa: "500,000 so'm" },
  { id: 2, ism: "Gulnora Karimova", sinf: "11-B", telefon: "+998 91 234 56 78", tolov: "Qarzdor", summa: "300,000 so'm" },
  { id: 3, ism: "Jasur Rahimov", sinf: "9-A", telefon: "+998 93 345 67 89", tolov: "To'ladi", summa: "500,000 so'm" },
  { id: 4, ism: "Madina Toshmatova", sinf: "10-B", telefon: "+998 94 456 78 90", tolov: "To'ladi", summa: "500,000 so'm" },
  { id: 5, ism: "Sardor Abdullayev", sinf: "11-A", telefon: "+998 95 567 89 01", tolov: "Qarzdor", summa: "450,000 so'm" },
  { id: 6, ism: "Nilufar Yusupova", sinf: "9-B", telefon: "+998 97 678 90 12", tolov: "To'ladi", summa: "500,000 so'm" },
  { id: 7, ism: "Bobur Mahmudov", sinf: "10-A", telefon: "+998 98 789 01 23", tolov: "Qarzdor", summa: "250,000 so'm" },
  { id: 8, ism: "Dilfuza Sharipova", sinf: "11-B", telefon: "+998 90 890 12 34", tolov: "To'ladi", summa: "500,000 so'm" },
  { id: 9, ism: "Otabek Umarov", sinf: "9-A", telefon: "+998 91 901 23 45", tolov: "To'ladi", summa: "500,000 so'm" },
  { id: 10, ism: "Zarina Normatova", sinf: "10-B", telefon: "+998 93 012 34 56", tolov: "Qarzdor", summa: "400,000 so'm" },
  { id: 11, ism: "Aziz Tursunov", sinf: "11-A", telefon: "+998 94 123 45 67", tolov: "To'ladi", summa: "500,000 so'm" },
  { id: 12, ism: "Feruza Alimova", sinf: "9-B", telefon: "+998 95 234 56 78", tolov: "To'ladi", summa: "500,000 so'm" },
  { id: 13, ism: "Rustam Ismoilov", sinf: "10-A", telefon: "+998 97 345 67 89", tolov: "Qarzdor", summa: "200,000 so'm" },
  { id: 14, ism: "Sabina Qodirova", sinf: "11-B", telefon: "+998 98 456 78 90", tolov: "To'ladi", summa: "500,000 so'm" },
  { id: 15, ism: "Timur Hamidov", sinf: "9-A", telefon: "+998 90 567 89 01", tolov: "To'ladi", summa: "500,000 so'm" },
];

export function StudentListTable() {
  const [qidiruv, setQidiruv] = useState("");
  const [sahifa, setSahifa] = useState(1);
  const sahifaHajmi = 8;

  // Qidirilgan o'quvchilar
  const filteredStudents = useMemo(() => {
    return mockStudents.filter((student) =>
      student.ism.toLowerCase().includes(qidiruv.toLowerCase())
    );
  }, [qidiruv]);

  // Sahifalash
  const jami = filteredStudents.length;
  const sahifalarSoni = Math.ceil(jami / sahifaHajmi);
  const boshlanish = (sahifa - 1) * sahifaHajmi;
  const tugash = boshlanish + sahifaHajmi;
  const currentStudents = filteredStudents.slice(boshlanish, tugash);

  const handleEdit = (id: number) => {
    console.log("Tahrirlash:", id);
    // Bu yerda tahrirlash funksiyasini amalga oshirasiz
  };

  const handleDelete = (id: number) => {
    console.log("O'chirish:", id);
    // Bu yerda o'chirish funksiyasini amalga oshirasiz
  };

  return (
    <div className="bg-white/40 backdrop-blur-lg rounded-2xl shadow-xl border border-white/50 overflow-hidden">
      {/* Qidiruv qismi */}
      <div className="p-6 border-b border-white/50 bg-gradient-to-r from-blue-500/10 to-purple-500/10">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-gray-400" />
          <Input
            type="text"
            placeholder="O'quvchi ismini qidiring..."
            value={qidiruv}
            onChange={(e) => {
              setQidiruv(e.target.value);
              setSahifa(1); // Qidiruvda birinchi sahifaga qaytish
            }}
            className="pl-10 bg-white/70 backdrop-blur border-white/50 focus:border-blue-400"
          />
        </div>
      </div>

      {/* Jadval */}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border-white/50 hover:bg-gradient-to-r hover:from-blue-500/20 hover:to-purple-500/20">
              <TableHead className="text-blue-900">№</TableHead>
              <TableHead className="text-blue-900">Ism Familiya</TableHead>
              <TableHead className="text-blue-900">Sinf</TableHead>
              <TableHead className="text-blue-900">Telefon</TableHead>
              <TableHead className="text-blue-900">Summa</TableHead>
              <TableHead className="text-blue-900">Holat</TableHead>
              <TableHead className="text-blue-900 text-right">Amallar</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {currentStudents.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-gray-500 h-32">
                  O'quvchi topilmadi
                </TableCell>
              </TableRow>
            ) : (
              currentStudents.map((student, index) => (
                <TableRow
                  key={student.id}
                  className="border-white/50 hover:bg-white/30 transition-colors"
                >
                  <TableCell className="text-gray-700">
                    {boshlanish + index + 1}
                  </TableCell>
                  <TableCell className="text-gray-900">{student.ism}</TableCell>
                  <TableCell className="text-gray-700">{student.sinf}</TableCell>
                  <TableCell className="text-gray-700">{student.telefon}</TableCell>
                  <TableCell className="text-gray-700">{student.summa}</TableCell>
                  <TableCell>
                    {student.tolov === "To'ladi" ? (
                      <Badge className="bg-green-500/90 hover:bg-green-600/90 text-white border-0 shadow-sm">
                        ✓ To'ladi
                      </Badge>
                    ) : (
                      <Badge className="bg-red-500/90 hover:bg-red-600/90 text-white border-0 shadow-sm">
                        ✗ Qarzdor
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-2 justify-end">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleEdit(student.id)}
                        className="hover:bg-blue-500/20 hover:text-blue-700 transition-colors"
                      >
                        <Edit2 className="size-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(student.id)}
                        className="hover:bg-red-500/20 hover:text-red-700 transition-colors"
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Sahifalash */}
      <div className="p-4 border-t border-white/50 bg-gradient-to-r from-purple-500/10 to-pink-500/10">
        <div className="flex items-center justify-between">
          <div className="text-gray-600">
            Jami: <span className="text-gray-900">{jami}</span> ta o'quvchi
            {qidiruv && ` (qidiruv natijasi)`}
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setSahifa((prev) => Math.max(prev - 1, 1))}
              disabled={sahifa === 1}
              className="bg-white/70 hover:bg-white/90 border-white/50 disabled:opacity-50"
            >
              <ChevronLeft className="size-4 mr-1" />
              Oldingi
            </Button>
            <div className="px-4 py-1 bg-white/70 rounded-md border border-white/50 text-gray-700">
              {sahifa} / {sahifalarSoni || 1}
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setSahifa((prev) => Math.min(prev + 1, sahifalarSoni))}
              disabled={sahifa === sahifalarSoni || sahifalarSoni === 0}
              className="bg-white/70 hover:bg-white/90 border-white/50 disabled:opacity-50"
            >
              Keyingi
              <ChevronRight className="size-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
