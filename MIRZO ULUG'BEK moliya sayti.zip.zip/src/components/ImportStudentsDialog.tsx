import { useState, useRef } from "react";
import { Upload, FileSpreadsheet, Download, CheckCircle2, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Alert, AlertDescription } from "./ui/alert";

interface ImportedStudent {
  ism: string;
  tugilgan: string;
  tuman: string;
  manzil: string;
  telefon1: string;
  telefon2?: string;
  sinf: string;
  fan1: string;
  fan2: string;
}

export function ImportStudentsDialog() {
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{
    success: boolean;
    count: number;
    message: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      const fileExtension = selectedFile.name.split('.').pop()?.toLowerCase();
      if (fileExtension === 'csv' || fileExtension === 'xlsx' || fileExtension === 'xls') {
        setFile(selectedFile);
        setImportResult(null);
      } else {
        setImportResult({
          success: false,
          count: 0,
          message: "Faqat CSV yoki Excel (.xlsx, .xls) fayllarini yuklash mumkin"
        });
      }
    }
  };

  const parseCSV = (text: string): ImportedStudent[] => {
    const lines = text.split('\n').filter(line => line.trim());
    const students: ImportedStudent[] = [];
    
    // Skip header line
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      // Handle quoted values
      const values = line.match(/(".*?"|[^,]+)(?=\s*,|\s*$)/g)?.map(v => 
        v.replace(/^"|"$/g, '').trim()
      ) || [];
      
      if (values.length >= 9) {
        students.push({
          ism: values[1] || '',
          tugilgan: values[2] || '',
          tuman: values[3] || '',
          manzil: values[4] || '',
          telefon1: values[5] || '',
          telefon2: values[6] || '',
          sinf: values[7] || '',
          fan1: values[8] || '',
          fan2: values[9] || '',
        });
      }
    }
    
    return students;
  };

  const handleImport = async () => {
    if (!file) return;
    
    setImporting(true);
    
    try {
      const text = await file.text();
      const students = parseCSV(text);
      
      if (students.length === 0) {
        setImportResult({
          success: false,
          count: 0,
          message: "Faylda o'quvchilar topilmadi. Formatni tekshiring."
        });
      } else {
        // Bu yerda real backend ga ma'lumotlarni yuborish kerak
        // Hozircha mock sifatida success ko'rsatamiz
        console.log('Imported students:', students);
        
        setImportResult({
          success: true,
          count: students.length,
          message: `${students.length} ta o'quvchi muvaffaqiyatli import qilindi!`
        });
        
        // 2 sekunddan keyin dialogni yopish
        setTimeout(() => {
          setOpen(false);
          setFile(null);
          setImportResult(null);
        }, 2000);
      }
    } catch (error) {
      setImportResult({
        success: false,
        count: 0,
        message: "Faylni o'qishda xatolik yuz berdi. Fayl formatini tekshiring."
      });
    } finally {
      setImporting(false);
    }
  };

  const downloadTemplate = () => {
    const template = `№,ISM FAMILIYA,TUG'ILGAN SANA,TUMAN,MANZIL,TELEFON 1,TELEFON 2,SINF,FAN 1,FAN 2
1,"Abdurashidova Odina Ahmadali qizi",08.12.2009,Beshariq,"Rapqon qishlog'i",998908502281,998912035496,10,Kimyo,Biologiya
2,"Nuraliyeva Dilzebo Sanjarbek qizi",04.05.2010,Pop,"Chorkesar qishlog'i",998957946484,998772534306,10,Kimyo,Biologiya`;

    const blob = new Blob(["\uFEFF" + template], {
      type: "text/csv;charset=utf-8;",
    });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    
    link.setAttribute("href", url);
    link.setAttribute("download", "Oquvchilar_Shablon.csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg rounded-xl">
          <Upload className="size-4 mr-2" />
          Excel dan import
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-purple-600 flex items-center gap-2">
            <FileSpreadsheet className="size-5" />
            O'quvchilarni Import Qilish
          </DialogTitle>
          <DialogDescription>
            Excel yoki CSV fayldan o'quvchilar ro'yxatini import qiling
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          {/* Template yuklab olish */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <FileSpreadsheet className="size-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <h4 className="text-blue-900 mb-1">Shablon faylni yuklab oling</h4>
                <p className="text-blue-700 text-sm mb-3">
                  To'g'ri formatda import qilish uchun avval shablon faylni yuklab olib, uni to'ldiring
                </p>
                <Button
                  onClick={downloadTemplate}
                  variant="outline"
                  size="sm"
                  className="bg-white border-blue-300 text-blue-700 hover:bg-blue-50"
                >
                  <Download className="size-4 mr-2" />
                  Shablon yuklab olish
                </Button>
              </div>
            </div>
          </div>

          {/* Fayl yuklash */}
          <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center hover:border-purple-400 transition-colors">
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={handleFileSelect}
              className="hidden"
            />
            
            {file ? (
              <div className="space-y-3">
                <div className="bg-purple-100 p-3 rounded-lg inline-block">
                  <FileSpreadsheet className="size-8 text-purple-600" />
                </div>
                <div>
                  <p className="text-slate-900">{file.name}</p>
                  <p className="text-slate-500 text-sm">
                    {(file.size / 1024).toFixed(2)} KB
                  </p>
                </div>
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  variant="outline"
                  size="sm"
                >
                  Boshqa fayl tanlash
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-slate-100 p-3 rounded-lg inline-block">
                  <Upload className="size-8 text-slate-400" />
                </div>
                <div>
                  <p className="text-slate-900 mb-1">Faylni yuklash</p>
                  <p className="text-slate-500 text-sm mb-3">
                    CSV yoki Excel (.xlsx, .xls) formatidagi faylni tanlang
                  </p>
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    Fayl tanlash
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Format yo'riqnomasi */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
            <h4 className="text-slate-900 mb-2">Fayl formati:</h4>
            <ul className="text-slate-600 text-sm space-y-1 ml-4">
              <li>• Birinchi qator - sarlavha (headers)</li>
              <li>• Har bir ustun: №, ISM FAMILIYA, TUG'ILGAN SANA, TUMAN, MANZIL, TELEFON 1, TELEFON 2, SINF, FAN 1, FAN 2</li>
              <li>• UTF-8 kodlashda saqlang</li>
              <li>• Vergul (,) bilan ajratilgan bo'lishi kerak</li>
            </ul>
          </div>

          {/* Import result */}
          {importResult && (
            <Alert className={importResult.success ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}>
              {importResult.success ? (
                <CheckCircle2 className="size-4 text-green-600" />
              ) : (
                <AlertCircle className="size-4 text-red-600" />
              )}
              <AlertDescription className={importResult.success ? "text-green-800" : "text-red-800"}>
                {importResult.message}
              </AlertDescription>
            </Alert>
          )}
        </div>

        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={() => setOpen(false)}>
            Bekor qilish
          </Button>
          <Button
            onClick={handleImport}
            disabled={!file || importing}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
          >
            {importing ? (
              <>
                <div className="size-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Import qilinmoqda...
              </>
            ) : (
              <>
                <Upload className="size-4 mr-2" />
                Import qilish
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
