import { useState } from "react";
import { Plus, Edit, Trash2 } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

const mockSubjects = [
  { id: 1, nom: "Matematika", oqituvchi: 3, oquvchi: 45 },
  { id: 2, nom: "Ingliz tili", oqituvchi: 4, oquvchi: 62 },
  { id: 3, nom: "Fizika", oqituvchi: 2, oquvchi: 38 },
  { id: 4, nom: "Kimyo", oqituvchi: 2, oquvchi: 41 },
  { id: 5, nom: "Biologiya", oqituvchi: 2, oquvchi: 35 },
  { id: 6, nom: "Tarix", oqituvchi: 1, oquvchi: 28 },
];

export function SubjectsModule() {
  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-2xl rounded-3xl shadow-lg border border-white/50 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-slate-900 mb-1">Yo'nalishlar</h1>
            <p className="text-slate-600">Yo'nalishlar ro'yxati va boshqaruvi</p>
          </div>
          <Button className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white shadow-lg rounded-xl">
            <Plus className="size-4 mr-2" />
            Yangi yo'nalish
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mockSubjects.map((fan) => (
            <Card key={fan.id} className="p-5 bg-gradient-to-br from-white to-slate-50 border border-slate-200 hover:shadow-lg transition-all duration-300 hover:scale-105 rounded-2xl">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-slate-900 text-lg">{fan.nom}</h3>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" className="hover:bg-blue-100 rounded-lg h-8 w-8 p-0">
                    <Edit className="size-4" />
                  </Button>
                  <Button size="sm" variant="ghost" className="hover:bg-red-100 text-red-600 rounded-lg h-8 w-8 p-0">
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-600 text-sm">O'qituvchilar:</span>
                  <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                    {fan.oqituvchi} ta
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-600 text-sm">O'quvchilar:</span>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    {fan.oquvchi} ta
                  </Badge>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}