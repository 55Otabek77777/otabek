import { useState } from "react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { User, Lock, LogIn } from "lucide-react";
import logoImage from "figma:asset/2f48f3791ecd205478f12f766bf06a64507cd70c.png";

interface LoginPageProps {
  onLogin: () => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [ripples, setRipples] = useState<Array<{id: number, x: number, y: number}>>([]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      onLogin();
    }
  };

  const createRipple = (e: React.MouseEvent<HTMLButtonElement>) => {
    const button = e.currentTarget;
    const rect = button.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const newRipple = { id: Date.now(), x, y };
    setRipples([...ripples, newRipple]);
    
    setTimeout(() => {
      setRipples(prev => prev.filter(r => r.id !== newRipple.id));
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 relative overflow-hidden flex items-center justify-center p-4">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-white/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-400/10 rounded-full blur-3xl animate-float-delayed"></div>
        <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-blue-400/10 rounded-full blur-3xl animate-pulse-slow"></div>
      </div>

      {/* Login Card */}
      <div className="relative z-10 w-full max-w-md">
        <div className="bg-white/10 backdrop-blur-2xl rounded-3xl shadow-2xl border border-white/20 p-8 md:p-10">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="w-24 h-24 mx-auto mb-4 relative">
              <div className="absolute inset-0 bg-white/20 backdrop-blur-xl rounded-full animate-ping"></div>
              <div className="absolute inset-0 bg-white rounded-full flex items-center justify-center animate-zoom-pulse">
                <img 
                  src={logoImage} 
                  alt="Mirzo Ulug'bek Logo" 
                  className="w-20 h-20 object-contain"
                />
              </div>
            </div>
            <h1 className="text-white text-3xl mb-2">Xush kelibsiz!</h1>
            <p className="text-white/80">Mirzo Ulug'bek Xususiy Maktabi</p>
            <p className="text-white/60 text-sm mt-1">Moliyaviy Boshqaruv Tizimi</p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label className="text-white/90 text-sm">Foydalanuvchi nomi</label>
              <div className="relative group">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-white/50 group-focus-within:text-white transition-colors" />
                <Input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Admin"
                  className="pl-12 bg-white/10 border-white/20 text-white placeholder:text-white/40 focus:bg-white/20 focus:border-white/40 transition-all h-12 rounded-xl backdrop-blur-xl"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-white/90 text-sm">Parol</label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-white/50 group-focus-within:text-white transition-colors" />
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="pl-12 bg-white/10 border-white/20 text-white placeholder:text-white/40 focus:bg-white/20 focus:border-white/40 transition-all h-12 rounded-xl backdrop-blur-xl"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              onClick={createRipple}
              className="w-full h-12 bg-gradient-to-r from-white/20 to-white/10 hover:from-white/30 hover:to-white/20 text-white border border-white/30 rounded-xl backdrop-blur-xl transition-all duration-300 hover:scale-105 hover:shadow-2xl relative overflow-hidden group"
            >
              {ripples.map((ripple) => (
                <span
                  key={ripple.id}
                  className="absolute bg-white/30 rounded-full animate-ripple"
                  style={{
                    left: ripple.x,
                    top: ripple.y,
                    width: 0,
                    height: 0,
                  }}
                />
              ))}
              <LogIn className="size-5 mr-2 group-hover:translate-x-1 transition-transform" />
              Kirish
            </Button>
          </form>

          {/* Footer */}
          <div className="mt-6 text-center">
            <p className="text-white/50 text-xs">© 2024 Mirzo Ulug'bek Xususiy Maktabi</p>
          </div>
        </div>

        {/* Glassmorphism decoration */}
        <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-purple-400/20 to-blue-400/20 rounded-full blur-2xl"></div>
        <div className="absolute -top-4 -left-4 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-indigo-400/20 rounded-full blur-2xl"></div>
      </div>
    </div>
  );
}