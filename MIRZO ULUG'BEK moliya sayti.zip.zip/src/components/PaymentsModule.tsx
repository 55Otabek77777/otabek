import { useState } from "react";
import { DollarSign, Users, GraduationCap, Printer } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

export function PaymentsModule() {
  const [summa, setSumma] = useState("");
  const [tanlangan, setTanlangan] = useState("");

  const handlePrint = () => {
    alert("Chek chiqarilmoqda...");
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-2xl rounded-3xl shadow-lg border border-white/50 p-6">
        <div className="mb-6">
          <h1 className="text-slate-900 mb-1">To'lovlar</h1>
          <p className="text-slate-600">To'lovlarni qabul qilish va boshqarish</p>
        </div>

        <Tabs defaultValue="student" className="space-y-6">
          <TabsList className="bg-white/80 backdrop-blur-xl border border-white/50 p-1 rounded-xl">
            <TabsTrigger value="student" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-600 data-[state=active]:to-emerald-600 data-[state=active]:text-white rounded-lg">
              <GraduationCap className="size-4 mr-2" />
              O'quvchi to'lovi
            </TabsTrigger>
            <TabsTrigger value="teacher" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-indigo-600 data-[state=active]:text-white rounded-lg">
              <Users className="size-4 mr-2" />
              O'qituvchi to'lovi
            </TabsTrigger>
          </TabsList>

          <TabsContent value="student">
            <Card className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-2xl">
              <h3 className="text-slate-900 mb-4 flex items-center gap-2">
                <DollarSign className="size-5 text-green-600" />
                O'quvchidan to'lov qabul qilish
              </h3>
              <div className="space-y-4">
                <div>
                  <Label>O'quvchini tanlang</Label>
                  <Select value={tanlangan} onValueChange={setTanlangan}>
                    <SelectTrigger className="bg-white border-green-200 rounded-xl">
                      <SelectValue placeholder="Tanlang..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">Abdurashidova Odina</SelectItem>
                      <SelectItem value="2">Nuraliyeva Dilzebo</SelectItem>
                      <SelectItem value="3">Tursunaliyeva Nilufar</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Summa (so'm)</Label>
                  <Input
                    type="number"
                    value={summa}
                    onChange={(e) => setSumma(e.target.value)}
                    placeholder="1 350 000"
                    className="bg-white border-green-200 rounded-xl"
                  />
                </div>
                <div className="flex gap-3">
                  <Button className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-xl h-12">
                    <DollarSign className="size-4 mr-2" />
                    To'lovni qabul qilish
                  </Button>
                  <Button
                    onClick={handlePrint}
                    variant="outline"
                    className="border-green-200 hover:bg-green-100 rounded-xl h-12"
                  >
                    <Printer className="size-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="teacher">
            <Card className="p-6 bg-gradient-to-br from-purple-50 to-indigo-50 border border-purple-200 rounded-2xl">
              <h3 className="text-slate-900 mb-4 flex items-center gap-2">
                <DollarSign className="size-5 text-purple-600" />
                O'qituvchiga to'lov berish
              </h3>
              <div className="space-y-4">
                <div>
                  <Label>O'qituvchini tanlang</Label>
                  <Select value={tanlangan} onValueChange={setTanlangan}>
                    <SelectTrigger className="bg-white border-purple-200 rounded-xl">
                      <SelectValue placeholder="Tanlang..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">Karimov Akmal</SelectItem>
                      <SelectItem value="2">Tursunova Nilufar</SelectItem>
                      <SelectItem value="3">Rahimov Javohir</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Summa (so'm)</Label>
                  <Input
                    type="number"
                    value={summa}
                    onChange={(e) => setSumma(e.target.value)}
                    placeholder="4 000 000"
                    className="bg-white border-purple-200 rounded-xl"
                  />
                </div>
                <div>
                  <Label>To'lov turi</Label>
                  <Select>
                    <SelectTrigger className="bg-white border-purple-200 rounded-xl">
                      <SelectValue placeholder="Tanlang..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="avans">Avans</SelectItem>
                      <SelectItem value="oylik">Oylik</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-3">
                  <Button className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl h-12">
                    <DollarSign className="size-4 mr-2" />
                    To'lovni berish
                  </Button>
                  <Button
                    onClick={handlePrint}
                    variant="outline"
                    className="border-purple-200 hover:bg-purple-100 rounded-xl h-12"
                  >
                    <Printer className="size-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
