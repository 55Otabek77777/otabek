import { useState } from "react";
import { UserPlus } from "lucide-react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

export function AddTeacherDialog() {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    ism: "",
    tugilgan: "",
    telefon: "",
    manzil: "",
    fan: "",
    oylikSumma: "",
    boshlanganSana: "",
  });

  const handleSubmit = () => {
    console.log("Yangi o'qituvchi:", formData);
    alert("O'qituvchi muvaffaqiyatli qo'shildi!");
    setOpen(false);
    // Reset form
    setFormData({
      ism: "",
      tugilgan: "",
      telefon: "",
      manzil: "",
      fan: "",
      oylikSumma: "",
      boshlanganSana: "",
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-lg rounded-xl">
          <UserPlus className="size-4 mr-2" />
          Yangi o'qituvchi
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-purple-600">Yangi O'qituvchi Qo'shish</DialogTitle>
          <DialogDescription>
            O'qituvchining barcha ma'lumotlarini to'liq kiriting
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Label>ISM FAMILIYA</Label>
              <Input
                value={formData.ism}
                onChange={(e) => setFormData({ ...formData, ism: e.target.value })}
                placeholder="Abdullayev Komil Alisher o'g'li"
                className="bg-white border-purple-200 rounded-xl"
              />
            </div>

            <div>
              <Label>TUG'ILGAN SANA</Label>
              <Input
                type="date"
                value={formData.tugilgan}
                onChange={(e) => setFormData({ ...formData, tugilgan: e.target.value })}
                className="bg-white border-purple-200 rounded-xl"
              />
            </div>

            <div>
              <Label>TELEFON</Label>
              <Input
                value={formData.telefon}
                onChange={(e) => setFormData({ ...formData, telefon: e.target.value })}
                placeholder="998901234567"
                className="bg-white border-purple-200 rounded-xl"
              />
            </div>

            <div className="col-span-2">
              <Label>MANZIL</Label>
              <Input
                value={formData.manzil}
                onChange={(e) => setFormData({ ...formData, manzil: e.target.value })}
                placeholder="Farg'ona shahar, Beshariq ko'chasi"
                className="bg-white border-purple-200 rounded-xl"
              />
            </div>

            <div>
              <Label>FAN (YO'NALISH)</Label>
              <Select value={formData.fan} onValueChange={(val) => setFormData({ ...formData, fan: val })}>
                <SelectTrigger className="bg-white border-purple-200 rounded-xl">
                  <SelectValue placeholder="Tanlang..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Matematika">Matematika</SelectItem>
                  <SelectItem value="Fizika">Fizika</SelectItem>
                  <SelectItem value="Kimyo">Kimyo</SelectItem>
                  <SelectItem value="Biologiya">Biologiya</SelectItem>
                  <SelectItem value="Ingliz tili">Ingliz tili</SelectItem>
                  <SelectItem value="Tarix">Tarix</SelectItem>
                  <SelectItem value="Adabiyot">Adabiyot</SelectItem>
                  <SelectItem value="Rus tili">Rus tili</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>OYLIK SUMMA (so'm)</Label>
              <Input
                type="number"
                value={formData.oylikSumma}
                onChange={(e) => setFormData({ ...formData, oylikSumma: e.target.value })}
                placeholder="5 000 000"
                className="bg-white border-purple-200 rounded-xl"
              />
            </div>

            <div>
              <Label>ISHGA BOSHLAGAN SANA</Label>
              <Input
                type="date"
                value={formData.boshlanganSana}
                onChange={(e) => setFormData({ ...formData, boshlanganSana: e.target.value })}
                className="bg-white border-purple-200 rounded-xl"
              />
            </div>
          </div>
        </div>
        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={() => setOpen(false)}>
            Bekor qilish
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={!formData.ism || !formData.fan || !formData.oylikSumma}
            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white"
          >
            <UserPlus className="size-4 mr-2" />
            Saqlash
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
