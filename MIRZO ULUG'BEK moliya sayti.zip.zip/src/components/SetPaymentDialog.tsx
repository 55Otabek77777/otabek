import { useState } from "react";
import { CreditCard, Search } from "lucide-react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

const OYLAR = ["AVGUST", "SENTYABR", "OKTYABR", "NOYABR", "DEKABR", "YANVAR", "FEVRAL", "MART", "APREL", "MAY", "IYUN", "IYUL"];

// Mock students for search
const mockStudents = [
  { id: 1, ism: "Abdurashidova Odina", sinf: "10" },
  { id: 2, ism: "Nuraliyeva Dilzebo", sinf: "10" },
  { id: 3, ism: "Tursunaliyeva Nilufar", sinf: "10" },
  { id: 4, ism: "Mamadaliyeva Zarinabonu", sinf: "8" },
];

export function SetPaymentDialog() {
  const [open, setOpen] = useState(false);
  const [qidiruv, setQidiruv] = useState("");
  const [tanlanganStudent, setTanlanganStudent] = useState<number | null>(null);
  const [oy, setOy] = useState("");
  const [summa, setSumma] = useState("");

  const filteredStudents = mockStudents.filter((s) =>
    s.ism.toLowerCase().includes(qidiruv.toLowerCase())
  );

  const handleSubmit = () => {
    const student = mockStudents.find((s) => s.id === tanlanganStudent);
    alert(`${student?.ism} uchun ${oy} oyi: ${summa} so'm to'lov belgilandi`);
    setOpen(false);
    setQidiruv("");
    setTanlanganStudent(null);
    setOy("");
    setSumma("");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg rounded-xl">
          <CreditCard className="size-4 mr-2" />
          To'lovni belgilash
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-blue-600">To'lovni Belgilash</DialogTitle>
          <DialogDescription>
            O'quvchini qidirib, oylik to'lov summasini belgilang
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label>O'quvchini qidirish</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
              <Input
                value={qidiruv}
                onChange={(e) => setQidiruv(e.target.value)}
                placeholder="Ism yoki familiyani kiriting..."
                className="pl-10 bg-white border-blue-200 rounded-xl"
              />
            </div>
          </div>

          {qidiruv && filteredStudents.length > 0 && (
            <div className="border border-blue-200 rounded-xl p-2 max-h-48 overflow-y-auto">
              {filteredStudents.map((student) => (
                <button
                  key={student.id}
                  onClick={() => {
                    setTanlanganStudent(student.id);
                    setQidiruv(student.ism);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-lg hover:bg-blue-50 transition-colors ${
                    tanlanganStudent === student.id ? "bg-blue-100" : ""
                  }`}
                >
                  <p className="text-slate-900">{student.ism}</p>
                  <p className="text-slate-500 text-sm">Sinf: {student.sinf}</p>
                </button>
              ))}
            </div>
          )}

          {tanlanganStudent && (
            <>
              <div>
                <Label>Oy</Label>
                <Select value={oy} onValueChange={setOy}>
                  <SelectTrigger className="bg-white border-blue-200 rounded-xl">
                    <SelectValue placeholder="Oyni tanlang..." />
                  </SelectTrigger>
                  <SelectContent>
                    {OYLAR.map((o) => (
                      <SelectItem key={o} value={o}>
                        {o}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Summa (so'm)</Label>
                <Input
                  type="number"
                  value={summa}
                  onChange={(e) => setSumma(e.target.value)}
                  placeholder="1 350 000"
                  className="bg-white border-blue-200 rounded-xl"
                />
              </div>
            </>
          )}
        </div>
        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={() => setOpen(false)}>
            Bekor qilish
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!tanlanganStudent || !oy || !summa}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
          >
            <CreditCard className="size-4 mr-2" />
            Belgilash
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
