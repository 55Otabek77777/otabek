import { useState } from "react";
import { Plus, Search, MoreVertical, Eye, DollarSign, Upload, FileText } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Label } from "./ui/label";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Textarea } from "./ui/textarea";
import { AddTeacherDialog } from "./AddTeacherDialog";

const mockTeachers = [
  { 
    id: 1, 
    ism: "Karimov Akmal Rahimovich", 
    fan: "Matematika", 
    maosh: 4000000, 
    telefon: "998901234567",
    tugilgan: "15.03.1985",
    manzil: "Farg'ona sh, Mustaqillik ko'chasi",
    kelganSana: "01.09.2020",
    sertifikat: true,
    avanslar: [
      { oy: "NOYABR", summa: 500000, sana: "05.11.2024" },
      { oy: "OKTYABR", summa: 1000000, sana: "10.10.2024" },
    ],
    oyliklar: [
      { oy: "OKTYABR", summa: 4000000, sana: "30.10.2024" },
    ]
  },
  { 
    id: 2, 
    ism: "Tursunova Nilufar Azimovna", 
    fan: "Ingliz tili", 
    maosh: 3500000, 
    telefon: "998907654321",
    tugilgan: "22.07.1990",
    manzil: "Beshariq tumani, Rapqon",
    kelganSana: "15.01.2021",
    sertifikat: false,
    avanslar: [],
    oyliklar: []
  },
  { 
    id: 3, 
    ism: "Rahimov Javohir Bekovich", 
    fan: "Fizika", 
    maosh: 3000000, 
    telefon: "998909876543",
    tugilgan: "10.12.1988",
    manzil: "Pop tumani",
    kelganSana: "01.09.2022",
    sertifikat: true,
    avanslar: [
      { oy: "NOYABR", summa: 800000, sana: "08.11.2024" },
    ],
    oyliklar: []
  },
];

type Teacher = typeof mockTeachers[0];

export function TeachersModule() {
  const [qidiruv, setQidiruv] = useState("");
  const [batafsilDialog, setBatafsilDialog] = useState(false);
  const [tolovDialog, setTolovDialog] = useState(false);
  const [sertifikatDialog, setSertifikatDialog] = useState(false);
  const [tanlanganTeacher, setTanlanganTeacher] = useState<Teacher | null>(null);
  const [tolovTuri, setTolovTuri] = useState("avans");
  const [tolovSumma, setTolovSumma] = useState("");

  const formatSumma = (summa: number) => {
    return new Intl.NumberFormat('uz-UZ').format(summa) + " so'm";
  };

  const handleBatafsil = (teacher: Teacher) => {
    setTanlanganTeacher(teacher);
    setBatafsilDialog(true);
  };

  const handleTolov = (teacher: Teacher) => {
    setTanlanganTeacher(teacher);
    setTolovDialog(true);
  };

  const handleSertifikat = (teacher: Teacher) => {
    setTanlanganTeacher(teacher);
    setSertifikatDialog(true);
  };

  const handleTolovBerishSubmit = () => {
    // To'lovni berish logikasi
    alert(`${tolovTuri === "avans" ? "Avans" : "Oylik"} berildi: ${tolovSumma} so'm`);
    setTolovDialog(false);
    setTolovSumma("");
  };

  // Olingan avanslar va oyliklarni hisoblash
  const getOlinganSumma = (teacher: Teacher) => {
    const jamiAvans = teacher.avanslar.reduce((sum, a) => sum + a.summa, 0);
    const jamiOylik = teacher.oyliklar.reduce((sum, o) => sum + o.summa, 0);
    return jamiAvans + jamiOylik;
  };

  const getQarzi = (teacher: Teacher) => {
    return teacher.maosh - getOlinganSumma(teacher);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-2xl rounded-3xl shadow-lg border border-white/50 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-slate-900 mb-1">O'qituvchilar</h1>
            <p className="text-slate-600">O'qituvchilar ro'yxati va boshqaruvi</p>
          </div>
          <AddTeacherDialog />
        </div>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" />
            <Input
              placeholder="Qidirish..."
              value={qidiruv}
              onChange={(e) => setQidiruv(e.target.value)}
              className="pl-10 bg-white border-slate-200 rounded-xl"
            />
          </div>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-slate-200">
          <Table>
            <TableHeader>
              <TableRow className="bg-gradient-to-r from-slate-50 to-slate-100">
                <TableHead>№</TableHead>
                <TableHead>ISM FAMILIYA</TableHead>
                <TableHead>FAN</TableHead>
                <TableHead>MAOSH</TableHead>
                <TableHead>OLGAN</TableHead>
                <TableHead>QARZ</TableHead>
                <TableHead>TELEFON</TableHead>
                <TableHead className="text-right">AMAL</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockTeachers.map((teacher, index) => {
                const olgan = getOlinganSumma(teacher);
                const qarz = getQarzi(teacher);
                
                return (
                  <TableRow key={teacher.id} className="hover:bg-blue-50/30 transition-colors">
                    <TableCell>
                      <span className="bg-slate-100 px-3 py-1 rounded-lg text-slate-700">
                        {index + 1}
                      </span>
                    </TableCell>
                    <TableCell className="text-slate-900">{teacher.ism}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                        {teacher.fan}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-slate-900">{formatSumma(teacher.maosh)}</TableCell>
                    <TableCell className="text-green-700">{formatSumma(olgan)}</TableCell>
                    <TableCell>
                      {qarz > 0 ? (
                        <span className="text-orange-700">{formatSumma(qarz)}</span>
                      ) : (
                        <Badge className="bg-green-500 text-white">To'liq</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-slate-600">+{teacher.telefon}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger className="hover:bg-blue-100 hover:text-blue-700 transition-colors px-3 py-2 rounded-md inline-flex items-center justify-center">
                          <MoreVertical className="size-4" />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleBatafsil(teacher)}>
                            <Eye className="size-4 mr-2" />
                            Batafsil
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleTolov(teacher)}>
                            <DollarSign className="size-4 mr-2" />
                            To'lov berish
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleSertifikat(teacher)}>
                            <Upload className="size-4 mr-2" />
                            Sertifikat yuklash
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Batafsil Dialog */}
      <Dialog open={batafsilDialog} onOpenChange={setBatafsilDialog}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-slate-900">O'qituvchi Haqida To'liq Ma'lumot</DialogTitle>
            <DialogDescription className="text-slate-600">
              O'qituvchining barcha ma'lumotlari va to'lovlar tarixi
            </DialogDescription>
          </DialogHeader>
          {tanlanganTeacher && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-slate-600">ISM FAMILIYA</Label>
                  <p className="text-slate-900">{tanlanganTeacher.ism}</p>
                </div>
                <div className="space-y-1">
                  <Label className="text-slate-600">TUG'ILGAN SANA</Label>
                  <p className="text-slate-900">{tanlanganTeacher.tugilgan}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-slate-600">FAN</Label>
                  <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                    {tanlanganTeacher.fan}
                  </Badge>
                </div>
                <div className="space-y-1">
                  <Label className="text-slate-600">TELEFON</Label>
                  <p className="text-slate-900">+{tanlanganTeacher.telefon}</p>
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-slate-600">MANZIL</Label>
                <p className="text-slate-900">{tanlanganTeacher.manzil}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-slate-600">KELGAN SANA</Label>
                  <p className="text-slate-900">{tanlanganTeacher.kelganSana}</p>
                </div>
                <div className="space-y-1">
                  <Label className="text-slate-600">SERTIFIKAT</Label>
                  {tanlanganTeacher.sertifikat ? (
                    <Badge className="bg-green-500 text-white">Mavjud</Badge>
                  ) : (
                    <Badge className="bg-red-500 text-white">Yo'q</Badge>
                  )}
                </div>
              </div>

              <div className="border-t pt-4">
                <Label className="text-slate-900 mb-2 block">Oylik Maosh</Label>
                <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-4 rounded-xl border border-purple-200">
                  <p className="text-purple-700 text-2xl">{formatSumma(tanlanganTeacher.maosh)}</p>
                </div>
              </div>

              <div className="border-t pt-4">
                <Label className="text-slate-900 mb-3 block">Avanslar Tarixi</Label>
                {tanlanganTeacher.avanslar.length === 0 ? (
                  <p className="text-slate-500 text-center py-4">Avans olmagan</p>
                ) : (
                  <div className="space-y-2">
                    {tanlanganTeacher.avanslar.map((avans, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200">
                        <div>
                          <p className="text-slate-900">{avans.oy}</p>
                          <p className="text-slate-500 text-sm">{avans.sana}</p>
                        </div>
                        <p className="text-orange-700">{formatSumma(avans.summa)}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="border-t pt-4">
                <Label className="text-slate-900 mb-3 block">Oyliklar Tarixi</Label>
                {tanlanganTeacher.oyliklar.length === 0 ? (
                  <p className="text-slate-500 text-center py-4">Oylik olmagan</p>
                ) : (
                  <div className="space-y-2">
                    {tanlanganTeacher.oyliklar.map((oylik, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                        <div>
                          <p className="text-slate-900">{oylik.oy}</p>
                          <p className="text-slate-500 text-sm">{oylik.sana}</p>
                        </div>
                        <p className="text-green-700">{formatSumma(oylik.summa)}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* To'lov Dialog */}
      <Dialog open={tolovDialog} onOpenChange={setTolovDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-purple-600">O'qituvchiga To'lov Berish</DialogTitle>
            <DialogDescription>
              {tanlanganTeacher?.ism} uchun to'lov ma'lumotlarini kiriting
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label>To'lov turi</Label>
              <Select value={tolovTuri} onValueChange={setTolovTuri}>
                <SelectTrigger className="bg-white border-purple-200 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="avans">Avans</SelectItem>
                  <SelectItem value="oylik">Oylik</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Summa (so'm)</Label>
              <Input
                type="number"
                value={tolovSumma}
                onChange={(e) => setTolovSumma(e.target.value)}
                placeholder={tanlanganTeacher ? formatSumma(tanlanganTeacher.maosh) : ""}
                className="bg-white border-purple-200 rounded-xl"
              />
            </div>
            {tanlanganTeacher && (
              <div className="bg-purple-50 p-4 rounded-xl border border-purple-200">
                <div className="flex justify-between mb-2">
                  <span className="text-slate-600">Oylik maosh:</span>
                  <span className="text-slate-900">{formatSumma(tanlanganTeacher.maosh)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-slate-600">Olgan:</span>
                  <span className="text-green-700">{formatSumma(getOlinganSumma(tanlanganTeacher))}</span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="text-slate-900">Qolgan qarz:</span>
                  <span className="text-orange-700">{formatSumma(getQarzi(tanlanganTeacher))}</span>
                </div>
              </div>
            )}
          </div>
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={() => setTolovDialog(false)}>
              Bekor qilish
            </Button>
            <Button 
              onClick={handleTolovBerishSubmit}
              disabled={!tolovSumma}
              className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white"
            >
              <DollarSign className="size-4 mr-2" />
              To'lov berish
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Sertifikat Dialog */}
      <Dialog open={sertifikatDialog} onOpenChange={setSertifikatDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-blue-600">Sertifikat Yuklash</DialogTitle>
            <DialogDescription>
              {tanlanganTeacher?.ism} uchun sertifikat faylini yuklang
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="border-2 border-dashed border-blue-200 rounded-2xl p-8 text-center hover:border-blue-400 transition-colors cursor-pointer group">
              <div className="flex flex-col items-center gap-3">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FileText className="size-8 text-blue-600" />
                </div>
                <div>
                  <p className="text-slate-900 mb-1">Faylni yuklash</p>
                  <p className="text-slate-500 text-sm">PDF, JPG, PNG (max 5MB)</p>
                </div>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                  <Upload className="size-4 mr-2" />
                  Fayl tanlash
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}