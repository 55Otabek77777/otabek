import { useState } from "react";
import { 
  Users, 
  GraduationCap, 
  DollarSign, 
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Calendar,
  TrendingDown,
  UserCheck,
  UserX,
  BarChart3
} from "lucide-react";
import { Card } from "./ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

const OYLAR = ["YANVAR", "FEVRAL", "MART", "APREL", "MAY", "IYUN", "IYUL", "AVGUST", "SENTYABR", "OKTYABR", "NOYABR", "DEKABR"];
const OQUV_YILLARI = ["2024-25", "2025-26", "2026-27", "2027-28"];

export function Dashboard() {
  const [tanlanganOy, setTanlanganOy] = useState("DEKABR");
  const [tanlanganYil, setTanlanganYil] = useState("2024-25");

  // Mock data
  const stats = {
    jamiOquvchi: 125,
    jamiOqituvchi: 18,
    tolovQilganOquvchi: 98,
    tolovQilmaganOquvchi: 27,
    oylikKirim: 168750000,
    oylikChiqim: 45000000,
  };

  const foyda = stats.oylikKirim - stats.oylikChiqim;

  // O'qituvchilar uchun statistika
  const oquvchilarStats = {
    tolagan: 15,
    tolamagan: 3,
    qarzdor: 3,
  };

  // Oylik to'lovlar ma'lumoti (oxirgi 6 oy)
  const oylikTolovlar = [
    { oy: "Iyul", kirim: 145000000, chiqim: 42000000 },
    { oy: "Avgust", kirim: 152000000, chiqim: 43000000 },
    { oy: "Sentyabr", kirim: 158000000, chiqim: 44000000 },
    { oy: "Oktyabr", kirim: 162000000, chiqim: 44500000 },
    { oy: "Noyabr", kirim: 165000000, chiqim: 45000000 },
    { oy: "Dekabr", kirim: 168750000, chiqim: 45000000 },
  ];

  // To'lovlar taqsimoti
  const tolovTaqsimoti = [
    { name: "To'lov qilgan", value: stats.tolovQilganOquvchi, color: "#10b981" },
    { name: "To'lov qilmagan", value: stats.tolovQilmaganOquvchi, color: "#ef4444" },
  ];

  // O'qituvchilar to'lovi
  const oquvchilarTolovi = [
    { name: "To'langan", value: oquvchilarStats.tolagan, color: "#10b981" },
    { name: "To'lanmagan", value: oquvchilarStats.tolamagan, color: "#f59e0b" },
    { name: "Qarzdor", value: oquvchilarStats.qarzdor, color: "#ef4444" },
  ];

  const formatSumma = (summa: number) => {
    return new Intl.NumberFormat('uz-UZ').format(summa) + " so'm";
  };

  const formatSummaQisqa = (summa: number) => {
    if (summa >= 1000000) {
      return (summa / 1000000).toFixed(1) + "M";
    }
    return summa.toString();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-2xl rounded-3xl shadow-lg border border-white/50 p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-slate-900 mb-1">Dashboard</h1>
            <p className="text-slate-600">Umumiy statistika va moliyaviy hisobotlar</p>
          </div>
          <div className="flex gap-3">
            <Select value={tanlanganOy} onValueChange={setTanlanganOy}>
              <SelectTrigger className="w-40 bg-white border-slate-200 rounded-xl">
                <Calendar className="size-4 mr-2 text-slate-400" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {OYLAR.map(oy => (
                  <SelectItem key={oy} value={oy}>{oy}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={tanlanganYil} onValueChange={setTanlanganYil}>
              <SelectTrigger className="w-40 bg-white border-slate-200 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {OQUV_YILLARI.map(yil => (
                  <SelectItem key={yil} value={yil}>{yil} o'quv yili</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden group">
          <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-white/20 p-3 rounded-xl backdrop-blur-xl group-hover:rotate-12 group-hover:scale-110 transition-all duration-300">
                <GraduationCap className="size-6" />
              </div>
              <Badge className="bg-white/20 border-white/30 text-white backdrop-blur-xl">
                Aktiv
              </Badge>
            </div>
            <p className="text-blue-100 text-sm mb-1">Jami O'quvchilar</p>
            <p className="text-3xl mb-2">{stats.jamiOquvchi}</p>
            <div className="flex items-center gap-1 text-blue-100 text-sm">
              <TrendingUp className="size-4" />
              <span>+12 bu oyda</span>
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-6 border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden group">
          <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-white/20 p-3 rounded-xl backdrop-blur-xl group-hover:rotate-12 group-hover:scale-110 transition-all duration-300">
                <Users className="size-6" />
              </div>
              <Badge className="bg-white/20 border-white/30 text-white backdrop-blur-xl">
                Kadrlar
              </Badge>
            </div>
            <p className="text-purple-100 text-sm mb-1">Jami O'qituvchilar</p>
            <p className="text-3xl mb-2">{stats.jamiOqituvchi}</p>
            <div className="flex items-center gap-1 text-purple-100 text-sm">
              <TrendingUp className="size-4" />
              <span>+2 bu oyda</span>
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white p-6 border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden group">
          <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-white/20 p-3 rounded-xl backdrop-blur-xl group-hover:rotate-12 group-hover:scale-110 transition-all duration-300">
                <CheckCircle2 className="size-6" />
              </div>
              <Badge className="bg-white/20 border-white/30 text-white backdrop-blur-xl">
                {tanlanganOy}
              </Badge>
            </div>
            <p className="text-green-100 text-sm mb-1">To'lov Qilgan</p>
            <p className="text-3xl mb-2">{stats.tolovQilganOquvchi}</p>
            <div className="flex items-center gap-1 text-green-100 text-sm">
              <span>{((stats.tolovQilganOquvchi / stats.jamiOquvchi) * 100).toFixed(1)}% to'lagan</span>
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white p-6 border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 relative overflow-hidden group">
          <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-white/20 p-3 rounded-xl backdrop-blur-xl group-hover:rotate-12 group-hover:scale-110 transition-all duration-300">
                <AlertCircle className="size-6" />
              </div>
              <Badge className="bg-white/20 border-white/30 text-white backdrop-blur-xl">
                Qarzdor
              </Badge>
            </div>
            <p className="text-red-100 text-sm mb-1">To'lov Qilmagan</p>
            <p className="text-3xl mb-2">{stats.tolovQilmaganOquvchi}</p>
            <div className="flex items-center gap-1 text-red-100 text-sm">
              <AlertCircle className="size-4" />
              <span>Eslatma yuborish kerak</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Oylik moliyaviy hisobot */}
      <Card className="bg-white/80 backdrop-blur-2xl border border-white/50 p-6 shadow-lg rounded-3xl">
        <h3 className="text-slate-900 mb-4 flex items-center gap-2">
          <DollarSign className="size-5 text-blue-600" />
          Oylik Moliyaviy Hisobot ({tanlanganOy})
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl border border-green-200">
            <div>
              <p className="text-slate-600 text-sm mb-1">Kirim</p>
              <p className="text-green-700 text-xl">{formatSumma(stats.oylikKirim)}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-xl">
              <TrendingUp className="size-6 text-green-600" />
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-red-50 to-orange-50 rounded-2xl border border-red-200">
            <div>
              <p className="text-slate-600 text-sm mb-1">Chiqim</p>
              <p className="text-red-700 text-xl">{formatSumma(stats.oylikChiqim)}</p>
            </div>
            <div className="bg-red-100 p-3 rounded-xl">
              <TrendingDown className="size-6 text-red-600" />
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-indigo-50 rounded-2xl border border-purple-200">
            <div>
              <p className="text-slate-600 text-sm mb-1">Foyda</p>
              <p className="text-purple-700 text-xl">{formatSumma(foyda)}</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-xl">
              <DollarSign className="size-6 text-purple-600" />
            </div>
          </div>
        </div>
      </Card>

      {/* Diagrammalar */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Oylik to'lovlar diagrammasi */}
        <Card className="bg-white/80 backdrop-blur-2xl border border-white/50 p-6 shadow-lg rounded-3xl">
          <h3 className="text-slate-900 mb-4 flex items-center gap-2">
            <BarChart3 className="size-5 text-blue-600" />
            Oxirgi 6 Oylik To'lovlar
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={oylikTolovlar}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="oy" stroke="#64748b" />
              <YAxis stroke="#64748b" tickFormatter={formatSummaQisqa} />
              <Tooltip 
                formatter={(value: number) => formatSumma(value)}
                contentStyle={{ 
                  backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                  borderRadius: '12px',
                  border: '1px solid #e2e8f0',
                  backdropFilter: 'blur(10px)'
                }}
              />
              <Bar dataKey="kirim" fill="#10b981" radius={[8, 8, 0, 0]} />
              <Bar dataKey="chiqim" fill="#ef4444" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* O'quvchilar to'lovi pie chart */}
        <Card className="bg-white/80 backdrop-blur-2xl border border-white/50 p-6 shadow-lg rounded-3xl">
          <h3 className="text-slate-900 mb-4 flex items-center gap-2">
            <GraduationCap className="size-5 text-green-600" />
            O'quvchilar To'lov Holati
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={tolovTaqsimoti}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {tolovTaqsimoti.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                  borderRadius: '12px',
                  border: '1px solid #e2e8f0',
                  backdropFilter: 'blur(10px)'
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* O'qituvchilar statistikasi */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* O'qituvchilar to'lovi */}
        <Card className="bg-white/80 backdrop-blur-2xl border border-white/50 p-6 shadow-lg rounded-3xl">
          <h3 className="text-slate-900 mb-4 flex items-center gap-2">
            <Users className="size-5 text-purple-600" />
            O'qituvchilar Oylik To'lov Holati
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl border border-green-200">
              <div className="flex items-center gap-3">
                <div className="bg-green-100 p-3 rounded-xl">
                  <UserCheck className="size-6 text-green-600" />
                </div>
                <div>
                  <p className="text-slate-600 text-sm mb-1">Oylik To'langan</p>
                  <p className="text-green-700 text-2xl">{oquvchilarStats.tolagan}</p>
                </div>
              </div>
              <Badge className="bg-green-100 text-green-700 border-green-200">
                {((oquvchilarStats.tolagan / stats.jamiOqituvchi) * 100).toFixed(0)}%
              </Badge>
            </div>

            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-2xl border border-orange-200">
              <div className="flex items-center gap-3">
                <div className="bg-orange-100 p-3 rounded-xl">
                  <UserX className="size-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-slate-600 text-sm mb-1">Oylik To'lanmagan</p>
                  <p className="text-orange-700 text-2xl">{oquvchilarStats.tolamagan}</p>
                </div>
              </div>
              <Badge className="bg-orange-100 text-orange-700 border-orange-200">
                {((oquvchilarStats.tolamagan / stats.jamiOqituvchi) * 100).toFixed(0)}%
              </Badge>
            </div>

            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-red-50 to-rose-50 rounded-2xl border border-red-200">
              <div className="flex items-center gap-3">
                <div className="bg-red-100 p-3 rounded-xl">
                  <AlertCircle className="size-6 text-red-600" />
                </div>
                <div>
                  <p className="text-slate-600 text-sm mb-1">Qarzdor O'qituvchilar</p>
                  <p className="text-red-700 text-2xl">{oquvchilarStats.qarzdor}</p>
                </div>
              </div>
              <Badge className="bg-red-100 text-red-700 border-red-200">
                Qarzdor
              </Badge>
            </div>
          </div>
        </Card>

        {/* O'qituvchilar to'lovi pie chart */}
        <Card className="bg-white/80 backdrop-blur-2xl border border-white/50 p-6 shadow-lg rounded-3xl">
          <h3 className="text-slate-900 mb-4 flex items-center gap-2">
            <Users className="size-5 text-purple-600" />
            O'qituvchilar To'lov Taqsimoti
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={oquvchilarTolovi}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {oquvchilarTolovi.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                  borderRadius: '12px',
                  border: '1px solid #e2e8f0',
                  backdropFilter: 'blur(10px)'
                }}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
}
