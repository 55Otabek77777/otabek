import { useState } from "react";
import { ArrowLeft, GraduationCap, MoreVertical, Eye } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Label } from "./ui/label";

// Mock data - har bir sinf uchun o'quvchilar
const classData = {
  "8": [
    { id: 1, ism: "Abdullayev Sardor", fan1: "Matematika", fan2: "Fizika" },
    { id: 2, ism: "Karimova Madina", fan1: "Ingliz tili", fan2: "Tarix" },
    { id: 3, ism: "Tursunov Jasur", fan1: "Kimyo", fan2: "Biologiya" },
  ],
  "9": [
    { id: 4, ism: "Rahimova Zilola", fan1: "Matematika", fan2: "Fizika" },
    { id: 5, ism: "Xolmatov Bekzod", fan1: "Ingliz tili", fan2: "Adabiyot" },
  ],
  "10": [
    { id: 6, ism: "Abdurashidova Odina", fan1: "Kimyo", fan2: "Biologiya" },
    { id: 7, ism: "Nuraliyeva Dilzebo", fan1: "Kimyo", fan2: "Biologiya" },
    { id: 8, ism: "Tursunaliyeva Nilufar", fan1: "Kimyo", fan2: "Biologiya" },
    { id: 9, ism: "Bahodirova Dilnura", fan1: "Kimyo", fan2: "Biologiya" },
  ],
  "11": [
    { id: 10, ism: "Mamadaliyev Sardor", fan1: "Matematika", fan2: "Fizika" },
    { id: 11, ism: "Yusupova Feruza", fan1: "Ingliz tili", fan2: "Tarix" },
  ],
};

const mockClasses = [
  { sinf: "8", oquvchi: 3 },
  { sinf: "9", oquvchi: 2 },
  { sinf: "10", oquvchi: 4 },
  { sinf: "11", oquvchi: 2 },
];

type Student = {
  id: number;
  ism: string;
  fan1: string;
  fan2: string;
  telefon?: string;
  manzil?: string;
  tugilgan?: string;
};

export function ClassesModule() {
  const [tanlanganSinf, setTanlanganSinf] = useState<string | null>(null);
  const [batafsilDialog, setBatafsilDialog] = useState(false);
  const [tanlanganStudent, setTanlanganStudent] = useState<Student | null>(null);

  const handleSinfClick = (sinf: string) => {
    setTanlanganSinf(sinf);
  };

  const handleBack = () => {
    setTanlanganSinf(null);
  };

  // Agar sinf tanlangan bo'lsa
  if (tanlanganSinf) {
    const students = classData[tanlanganSinf as keyof typeof classData] || [];
    
    return (
      <div className="space-y-6">
        <div className="bg-white/80 backdrop-blur-2xl rounded-3xl shadow-lg border border-white/50 p-6">
          <div className="flex items-center gap-4 mb-6">
            <Button
              onClick={handleBack}
              variant="ghost"
              className="hover:bg-blue-100 rounded-xl"
            >
              <ArrowLeft className="size-5" />
            </Button>
            <div>
              <h1 className="text-slate-900">{tanlanganSinf}-sinf O'quvchilari</h1>
              <p className="text-slate-600">Jami: {students.length} ta o'quvchi</p>
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200">
            <Table>
              <TableHeader>
                <TableRow className="bg-gradient-to-r from-slate-50 to-slate-100">
                  <TableHead>№</TableHead>
                  <TableHead>ISM FAMILIYA</TableHead>
                  <TableHead>YO'NALISH (FAN 1)</TableHead>
                  <TableHead>FAN 2</TableHead>
                  <TableHead className="text-right">AMAL</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students.map((student, index) => (
                  <TableRow key={student.id} className="hover:bg-blue-50/30 transition-colors">
                    <TableCell>
                      <span className="bg-slate-100 px-3 py-1 rounded-lg text-slate-700">
                        {index + 1}
                      </span>
                    </TableCell>
                    <TableCell className="text-slate-900">{student.ism}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                        {student.fan1}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                        {student.fan2}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger className="hover:bg-blue-100 hover:text-blue-700 transition-colors px-3 py-2 rounded-md inline-flex items-center justify-center">
                          <MoreVertical className="size-4" />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => {
                            setTanlanganStudent(student);
                            setBatafsilDialog(true);
                          }}>
                            <Eye className="size-4 mr-2" />
                            Batafsil
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    );
  }

  // Sinflar ro'yxati
  return (
    <div className="space-y-6">
      <div className="bg-white/80 backdrop-blur-2xl rounded-3xl shadow-lg border border-white/50 p-6">
        <div className="mb-6">
          <h1 className="text-slate-900 mb-1">Sinflar</h1>
          <p className="text-slate-600">Sinflar bo'yicha o'quvchilar soni</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {mockClasses.map((item) => (
            <Card 
              key={item.sinf}
              onClick={() => handleSinfClick(item.sinf)}
              className="p-8 bg-gradient-to-br from-pink-500 to-rose-500 text-white hover:shadow-2xl transition-all duration-300 hover:scale-110 rounded-3xl cursor-pointer group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              <div className="text-center relative z-10">
                <div className="mb-4 flex justify-center">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-xl rounded-full flex items-center justify-center group-hover:rotate-12 group-hover:scale-110 transition-all">
                    <GraduationCap className="size-8" />
                  </div>
                </div>
                <h2 className="mb-3 text-4xl">{item.sinf}</h2>
                <p className="text-pink-100 mb-3">sinf</p>
                <Badge className="bg-white/20 border-white/30 backdrop-blur-xl text-white">
                  {item.oquvchi} o'quvchi
                </Badge>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Batafsil Dialog */}
      <Dialog open={batafsilDialog} onOpenChange={setBatafsilDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="text-slate-900">O'quvchi Haqida Batafsil</DialogTitle>
            <DialogDescription className="text-slate-600">
              O'quvchining to'liq ma'lumotlari
            </DialogDescription>
          </DialogHeader>
          {tanlanganStudent && (
            <div className="space-y-4 py-4">
              <div>
                <Label className="text-slate-600">ISM FAMILIYA</Label>
                <p className="text-slate-900 text-lg">{tanlanganStudent.ism}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-slate-600">YO'NALISH (FAN 1)</Label>
                  <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200 mt-1">
                    {tanlanganStudent.fan1}
                  </Badge>
                </div>
                <div>
                  <Label className="text-slate-600">FAN 2</Label>
                  <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200 mt-1">
                    {tanlanganStudent.fan2}
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-slate-600">TUG'ILGAN SANA</Label>
                  <p className="text-slate-900">{tanlanganStudent.tugilgan || "Ma'lumot kiritilmagan"}</p>
                </div>
                <div>
                  <Label className="text-slate-600">TELEFON</Label>
                  <p className="text-slate-900">{tanlanganStudent.telefon ? `+${tanlanganStudent.telefon}` : "Ma'lumot kiritilmagan"}</p>
                </div>
              </div>

              <div>
                <Label className="text-slate-600">MANZIL</Label>
                <p className="text-slate-900">{tanlanganStudent.manzil || "Ma'lumot kiritilmagan"}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}