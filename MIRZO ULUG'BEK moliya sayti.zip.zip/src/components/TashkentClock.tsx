import { useState, useEffect } from "react";
import { Clock } from "lucide-react";

export function TashkentClock() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Toshkent vaqtiga o'tkazish (UTC+5)
  const tashkentTime = new Date(currentTime.toLocaleString("en-US", { timeZone: "Asia/Tashkent" }));
  
  const hours = String(tashkentTime.getHours()).padStart(2, "0");
  const minutes = String(tashkentTime.getMinutes()).padStart(2, "0");
  const seconds = String(tashkentTime.getSeconds()).padStart(2, "0");

  const day = tashkentTime.getDate();
  const year = tashkentTime.getFullYear();
  
  const oylar = [
    "Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun",
    "Iyul", "Avgust", "Sentyabr", "Oktyabr", "Noyabr", "Dekabr"
  ];
  const oy = oylar[tashkentTime.getMonth()];

  return (
    <div className="bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-600 rounded-2xl p-4 shadow-lg border border-white/20 backdrop-blur-xl relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 bg-white/10 animate-pulse-slow"></div>
      
      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-3">
          <div className="bg-white/20 backdrop-blur-xl rounded-xl p-2 animate-bounce-subtle">
            <Clock className="size-5 text-white" />
          </div>
          <div className="text-white tabular-nums tracking-wider font-mono">
            <span className="text-3xl drop-shadow-lg">{hours}</span>
            <span className="text-3xl animate-pulse text-white/80">:</span>
            <span className="text-3xl drop-shadow-lg">{minutes}</span>
            <span className="text-3xl animate-pulse text-white/80">:</span>
            <span className="text-2xl drop-shadow-lg">{seconds}</span>
          </div>
        </div>
        <div className="text-white/90 text-sm pl-1 drop-shadow">
          {year} yil {day} {oy}
        </div>
      </div>
    </div>
  );
}