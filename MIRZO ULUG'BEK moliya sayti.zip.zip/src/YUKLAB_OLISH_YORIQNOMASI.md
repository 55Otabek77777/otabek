# 🎉 MIRZO ULUG'BEK MAKTABI - MOLIYAVIY BOSHQARUV TIZIMI

## 📥 SAYTNI QANDAY YUKLAB OLISH MUMKIN?

### **USUL 1: Figma Make Platformasidan To'g'ridan-To'g'ri Yuklab Olish**

Agar siz Figma Make platformasida ishlayotgan bo'lsangiz:

1. **Ekranning yuqori o'ng burchagidagi "Download" tugmasini bosing**
   - Bu tugma odatda ekranning eng yuqori qismida joylashgan
   - Tugmada "Download" yoki yuklab olish belgisi bo'ladi

2. **Yuklab olingan ZIP faylni toping**
   - Fayl kompyuteringizning "Downloads" (Yuklanmalar) papkasida bo'ladi
   - Fayl nomi masalan: `mirzo-ulugbek-finance-system.zip`

3. **ZIP faylni oching (extract qiling)**
   - Windows: ZIP faylga o'ng tugma bosib "Extract All..." ni tanlang
   - Mac: ZIP faylga ikki marta bosing

---

## 🌐 SAYTNI HOSTINGGA QANDAY JOYLASHTIRISH MUMKIN?

### **TAVSIYA ETILADIGAN HOSTING PLATFORMALARI:**

#### **1. VERCEL (ENG OSON VA BEPUL)**

**Qadamlar:**

1. **Vercel.com saytiga kiring**
   ```
   https://vercel.com
   ```

2. **"Sign Up" tugmasini bosib ro'yxatdan o'ting**
   - GitHub, GitLab yoki Email orqali ro'yxatdan o'ting

3. **Yangi loyiha yaratish:**
   - Dashboard'da "New Project" tugmasini bosing
   - "Import Git Repository" o'rniga "Upload" tugmasini bosing
   - Yuklab olingan ZIP faylni yuklang

4. **Deploy qilish:**
   - "Deploy" tugmasini bosing
   - 2-3 daqiqada sayt tayyor bo'ladi
   - Sizga bepul domen beriladi: `https://sizning-loyihangiz.vercel.app`

**AFZALLIKLARI:**
- ✅ Bepul
- ✅ Tezkor (1-2 daqiqa ichida)
- ✅ Avtomatik HTTPS
- ✅ O'z domeningizni ulash mumkin

---

#### **2. NETLIFY (Ham Oson va Bepul)**

**Qadamlar:**

1. **Netlify.com saytiga kiring**
   ```
   https://www.netlify.com
   ```

2. **"Sign Up" qiling**

3. **Fayllarni yuklash:**
   - Dashboard'da "Sites" bo'limiga o'ting
   - ZIP faylni to'g'ridan-to'g'ri sahifaga torting (Drag & Drop)
   - Yoki "Upload" tugmasini bosing

4. **Deploy:**
   - Avtomatik deploy qilinadi
   - Sizga domen beriladi: `https://sizning-loyihangiz.netlify.app`

**AFZALLIKLARI:**
- ✅ Bepul
- ✅ Drag & Drop yuklash
- ✅ Avtomatik HTTPS
- ✅ O'z domeningizni ulash mumkin

---

#### **3. O'Z DOMENINGIZNI ULASH**

Agar sizda domen (masalan: `mirzoschool.uz`) bo'lsa:

**Vercel uchun:**
1. Vercel dashboard → Project Settings → Domains
2. O'z domeningizni kiriting
3. DNS sozlamalarini yangilang (Vercel yo'riqnomasi bo'yicha)

**Netlify uchun:**
1. Site Settings → Domain Management → Add Custom Domain
2. DNS sozlamalarini yangilang

---

## 📂 SAYT TARKIBI

Yuklab olingan ZIP faylda quyidagi papkalar va fayllar bo'ladi:

```
mirzo-ulugbek-finance-system/
├── components/           # Barcha komponentlar
│   ├── ui/              # UI komponentlar (Shadcn)
│   ├── Dashboard.tsx    # Asosiy dashboard
│   ├── ProfessionalStudentTable.tsx
│   ├── TeacherManagement.tsx
│   ├── AddStudentDialog.tsx
│   ├── ImportStudentsDialog.tsx
│   └── ...
├── styles/
│   └── globals.css      # Global CSS
├── App.tsx              # Asosiy komponent
├── package.json         # Dependencies
└── ...
```

---

## 🔧 MAHALLIY KOMPYUTERDA ISHLATISH (DEVELOPMENT)

Agar siz saytni mahalliy kompyuteringizda ishlatmoqchi bo'lsangiz:

**1. Node.js o'rnating**
```
https://nodejs.org/ dan yuklab oling
```

**2. Terminal/CMD da loyiha papkasiga kiring**
```bash
cd mirzo-ulugbek-finance-system
```

**3. Kutubxonalarni o'rnating**
```bash
npm install
```

**4. Saytni ishga tushiring**
```bash
npm run dev
```

**5. Brauzerda oching**
```
http://localhost:5173
```

---

## 📊 EXCEL IMPORT FUNKSIYASI QANDAY ISHLAYDI?

1. **O'quvchilar bo'limiga o'ting**

2. **"Excel dan import" tugmasini bosing**

3. **Shablon faylni yuklab oling:**
   - Dialog oynasida "Shablon yuklab olish" tugmasini bosing
   - `Oquvchilar_Shablon.csv` fayli yuklab olinadi

4. **Shablon faylni to'ldiring:**
   - Excel yoki Google Sheets da oching
   - O'quvchilar ma'lumotlarini kiriting
   - Formatni o'zgartirmang!

5. **To'ldirilgan faylni import qiling:**
   - "Fayl tanlash" tugmasini bosing
   - To'ldirilgan CSV faylni tanlang
   - "Import qilish" tugmasini bosing

**MUHIM:** 
- ✅ Faqat CSV yoki Excel (.xlsx, .xls) formatida
- ✅ UTF-8 kodlashda saqlang
- ✅ Vergul (,) bilan ajratilgan bo'lishi kerak

---

## 🎨 TIZIM IMKONIYATLARI

### ✅ **Dashboard:**
- Umumiy statistika
- Oylik va yillik moliyaviy hisobotlar
- Diagrammalar va grafiklar
- O'qituvchilar oylik to'lov holati

### ✅ **O'quvchilar Bo'limi:**
- Excel/CSV dan import qilish
- Yangi o'quvchi qo'shish
- To'lovlarni belgilash
- Excel ga eksport
- Qidiruv va filtrlash
- Batafsil ma'lumot
- Chetlatish va jarima

### ✅ **O'qituvchilar Bo'limi:**
- Avans/Oylik tizimi
- Sertifikat yuklash
- Batafsil ma'lumot

### ✅ **Yo'nalishlar (Fanlar):**
- Fanlar ro'yxati
- Yangi fan qo'shish

### ✅ **Sinflar:**
- "8-sinf (3 o'quvchi)" formatida
- Sinfni bosganda o'quvchilar ro'yxati

### ✅ **Hududlar:**
- Tumanlar bo'yicha statistika

### ✅ **To'lovlar:**
- To'lovlar tarixi
- Oylik hisobotlar

---

## 🔐 LOGIN MA'LUMOTLARI

**Demo login uchun:**
- **Login:** admin
- **Parol:** admin123

**MUHIM:** Real saytda bu ma'lumotlarni o'zgartiring!

---

## 💡 QO'SHIMCHA MASLAHATLAR

1. **HTTPS:**
   - Vercel va Netlify avtomatik HTTPS beradi
   - Bu xavfsizlik uchun juda muhim

2. **Backup:**
   - Har doim sayt fayllarining zaxira nusxasini saqlang
   - GitHub'ga yuklash tavsiya etiladi

3. **Yangilanishlar:**
   - Muntazam ravishda tizimni yangilang
   - Xavfsizlik patch'larini o'rnating

4. **Support:**
   - Hosting platformalarining support xizmatidan foydalaning
   - Ko'plab bepul video darsliklar mavjud

---

## 📞 YORDAM KERAKMI?

**Hosting bo'yicha video darsliklar:**
- YouTube'da "Vercel deployment tutorial" qidiring
- YouTube'da "Netlify deployment tutorial" qidiring

**O'zbek tilida:**
- "Vebsaytni hostingga joylashtirish" deb qidiring
- IT bloglar va YouTube kanallar

---

## 🎯 MUVAFFAQIYATLAR!

Saytingiz tayyor! Endi uni hosting'ga joylashtirib, maktabingizda ishlatishingiz mumkin.

**Omad tilaymiz! 🚀**

---

**Muallif:** Figma Make AI Assistant  
**Sana:** 2024  
**Versiya:** 1.0  
