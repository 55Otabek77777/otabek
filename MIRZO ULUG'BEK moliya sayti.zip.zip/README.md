
  # Student List Table Component

  This is a code bundle for Student List Table Component. The original project is available at https://www.figma.com/design/sIkdIkXJh5xCjfgrQVGYDA/Student-List-Table-Component.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  